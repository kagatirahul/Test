Addplan()
{
	
	lr_start_transaction("S01_AddItemtoCart_T70_ClickNoThanksButton");
	
	
	web_custom_request("redeem_6", 
		"URL={URL}/nap/napkinapi/v1/ticketing/redeem?ticket={C_ticketCart}", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", 
		"Snapshot=t85.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=redeem?ticket={C_ticketCart}", "Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", ENDITEM, 
		"Url=https://securepubads.g.doubleclick.net/gampad/ads?gdfp_req=1&pvsid=2540991449657275&correlator=2256885127250256&output=ldjh&impl=fif&eid=31061160%2C31061848%2C31061199%2C20211866&vrg=2021071501&ptt=17&sc=1&sfv=1-0-38&ecs=20210720&iu_parts=2455%2Cebay.au.vip%2CMPU&enc_prev_ius=%2F0%2F1%2F2&prev_iu_szs=300x250&fsfs=1&ris=34&rcs=1&prev_scp="
		"ap%3DScandal%26cat%3D888%2C7294%2C177831%26iid%3D313558273509%26it%3DUnisex%2520Adult%2520Mountain%2520Bike%2520Full%2520Suspension%252026%252021%2520Speed%2520MTB%2520Folding%2520Bicycle%26ip%3D32%26ccode%3DAUD%26if%3Db%26smdid%3D1520453025306022531802AAAAAAAAAA%26cg%3Dc1b6713217a0a6466f344290f9d5e5a3%26g%3Dc1b666c317a0a4d6b0caaf40ffff8417%26us%3D13%26um%3D0%26ot%3D1%26fvi%3D888%26svi%3D7294%26tvi%3D177831%26kw%3DUnisex%2520Adult%2520Mountain%2520Bike%2520Full%2520Suspension%252026%252021%2520Spe"
		"ed%2520MTB%2520Folding%2520Bicycle%26lkw%3Dbike%26cid%3D0%26nc%3D0%26rd%3D19691231%26fm%3D0%26sfm%3D0%26ic%3D0%26pr%3D20%26xp%3D20%26np%3D20%26u%3D5945e7bafd5b4f01a970bc622cd319b7%26bb%3D0%26dd%3D0%26c2c%3D0%26ipp%3D0%26iccr%3D0%26gdprUser%3D0%26plmtid%3D100562%26acc%3Dext%26slc%3D19476%2C20506%2C20511%2C20501%2C23641%2C26125%2C26314%2C26302%2C216%2C17220%2C19471%2C20016%2C19781%2C19811%26to_pb%3Dnobid%26to_bidder%3Dnobid%26to_adid%3Dnobid%26to_adsize%3Dnobid%26refresh%3D1%26rcount%3D1&eri=1&"
		"cookie=ID%3Dc805df014454b760%3AT%3D1626747633%3AS%3DALNI_Mb29AVfagXNae3XvZe4CT8icknGYw&bc=31&abxe=1&lmt=1626771384&dt=1626771384017&dlt=1626771334272&idt=15278&frm=20&biw=1903&bih=969&oid=3&adxs=1379&adys=524&adks=4028896849&ucis=3&ifi=3&u_tz=600&u_his=3&u_java=false&u_h=1080&u_w=1920&u_ah=1040&u_aw=1920&u_cd=24&u_nplug=3&u_nmime=4&u_sd=1&flash=0&url=https%3A%2F%2Fwww.ebay.com.au%2Fitm%2F313558273509%3Fhash%3Ditem4901878de5%3Ag%3AL-YAAOSwASVg2CUt&ref="
		"https%3A%2F%2Fwww.ebay.com.au%2Fsch%2Fi.html%3F_from%3DR40%26_trksid%3Dp2380057.m570.l1313%26_nkw%3Dbike%26_sacat%3D0&vis=1&dmc=8&scr_x=0&scr_y=0&psz=300x592&msz=300x254&ga_vid=2053175122.1626771350&ga_sid=1626771350&ga_hid=1420897058&ga_fc=false&fws=0&ohw=0&btvi=0", "Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", ENDITEM, 
		"Url=https://adservice.google.com.au/adsid/integrator.js?domain=www.ebay.com.au", "Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", ENDITEM, 
		"Url=https://adservice.google.com/adsid/integrator.js?domain=www.ebay.com.au", "Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", ENDITEM, 
		LAST);
	
	
	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_custom_request("9_6",
		"URL=https://pulsar.ebay.com.au/plsr/mpe/0/SAND/9?pld=%5B%7B%22ef%22%3A%22SAND%22%2C%22ea%22%3A%223PADS%22%2C%22pge%22%3A2367355%2C%22plsUBT%22%3A1%2C%22app%22%3A%22Sandwich%22%2C%22callingEF%22%3A%22SAND%22%2C%22difTS%22%3A1%2C%22eventOrder%22%3A0%2C%22cp%22%3A2047675%2C%22scandal_trk%22%3A%22meid%3A{C_ticketCart}%2Cplid%3A100562%2Cw%3A300%2Ch%3A250%2Ccid%3A138222862143%2Cliid%3A900453536%2Cempty%3Afalse%2Cprvdr%3Ahybrid%2Cerrmsg%3AUnexpected%2520error%2520in%2520Napkin%2520Ajax%2520call%2Cafs%3A1626771349561%2Cafe%3A1626771353939%2Cars%3A1626771353940%2Care%3A1626771356764%2Civ%3A1626771355431%2Cview1s%3Atrue%7Cmeid%3A3c11a1871d054b0da358b9d6e0c1663a%2Cplid%3A100567%2Cw%3A375%2Ch%3A35%2Ccid%3A138273363069%2Cliid%3A5094698128%2Cempty%3Afalse%2Cprvdr%3AdfpNativeDisplay%2Cafs%3A1626771349565%2Cafe%3A1626771353840%2Cars%3A1626771353840%2Care%3A1626771356639%22%2C%22scandal_timings%22%3A%22sjsv%3A2.1.31%2Cload%3A1626771349508%2Cdata_collected%3A1626771383095%2Cgss_ts%3A1626771342041%2Cbw%3A1920%2Cbh%3A969%2Csh%3A108"
		"0%2Csw%3A1920%22%7D%5D",
		"Method=POST",
		"Resource=0",
		"RecContentType=image/gif",
		"Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt",
		"Snapshot=t86.inf",
		"EncType=text/plain;charset=UTF-8",
		LAST);

	
	/*Correlation comment - Do not change!  Original value='01000600000050854c0f419bdd178ac5c9630297c5b4df286b0648c592b26c47dd200114061bfcf291821d43a154d7f8d4ffa0921eb90406a5ee7fabf507ac661d6fe37df1e48ad3f5ef577a047b3052159b3990e10c75' Name ='C_Srt' Type ='Manual'*/
	web_reg_save_param_regexp(
		"ParamName=C_Srt",
		"RegExp=\\ data-token=\"(.*?)\"><span",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
web_reg_find("Text=samplingRate",   LAST );

	web_url("add",
		"URL=https://cart.payments.ebay.com.au/sc/add?srt={C_srt1}&ssPageName=CART:ATC&item=iid:313558273509,qty:1,vid:612384340773",
		"Resource=0",
		"RecContentType=text/html",
		"Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt",
		"Snapshot=t90.inf",
		"Mode=HTML",
		LAST);
	
		web_revert_auto_header("X-Client-Data");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Origin", 
		"https://cart.payments.ebay.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

		web_reg_find("Text=logName",   LAST );
		
	web_custom_request("client-logging",
		"URL=https://cart.payments.ebay.com.au/api/client-logging",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://cart.payments.ebay.com.au/",
		"Snapshot=t93.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"logType\":\"info\",\"logName\":\"[CLIENT_LOAD_TIME]\",\"clientLoadStart\":4102.985000004992,\"clientLoadEnd\":4409.590000053868,\"clientLoadTotal\":306.6050000488758,\"logMessage\":\"\",\"srt\":\"{C_Srt}\"}",
		LAST);

	
	
	lr_end_transaction("S01_AddItemtoCart_T70_ClickNoThanksButton",LR_AUTO);
	
	lr_think_time(thinktime);
		
	return 0;
}
