vuser_init()
{
	
	/*********************************************************************************************************************
	Test script Information
	**********************************************************************************************************************
	
	Script Name : S01_AddItemtoCart
	
	Application Name: ebay.com.au
	
	Scneario: 
	
		Test Case 1 � Verify item added to cart is displayed in the cart.
		
		1.       Navigate to ebay.com.au
		
		2.       Search for �bike�
		
		3.       Click on the first bike item in the list
		
		4.       Click on �Add to cart�
		
		5.       Go to cart
		
		6.       Verify that the item is displayed in the cart
	
	Author: Rahul Kagathi
	
	creation Date: 21/07/2021
	Updated Date: 21/07/2021
	Version: V0.1
	Key Information related to this script: 
		- This script has been developed in Virtual User Generator Version: 2020.3.305.0
		- The application under test uses SSL 1.2
		- SearchString paramater file needs to updated with different variety of data.
		
		Note:
		
		Pls take out the proxy and user credential before execution.
		**********************************************************************************************************************
	 **	/*****************************************************************************************************************/
	
	
	web_set_sockets_option("SSL_VERSION", "AUTO");
		
		
	web_reg_save_param("C_ticket", "LB=ammiid\":\"", "RB=\"","ord=1", LAST);	
	

lr_start_transaction("S01_AddItemtoCart_T10_Homepage");
		
		
	web_url("ebay.com.au", 
		"URL=https://ebay.com.au/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://ir.ebaystatic.com/pictures/aw/pics/cmp/ds3/sprds3_20.png", "Referer=https://ir.ebaystatic.com/rs/v/vd0fjlgwua5qnokbp5vgu1p33az.css?proc=DU:N", ENDITEM, 
		"Url=https://ir.ebaystatic.com/rs/v/acxp0mbuba3zva1qr31idsmitmi.png", "Referer=https://ir.ebaystatic.com/rs/v/vd0fjlgwua5qnokbp5vgu1p33az.css?proc=DU:N", ENDITEM, 
		"Url=https://i.ebayimg.com/00/s/MzZYNDI=/z/BGEAAOSw8FRZqY4x/$_57.PNG", "Referer=https://ir.ebaystatic.com/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/ewgAAOSwCl5g79gL/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/YEcAAOSw-jlg79gL/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/kigAAOSwPM9g8NOe/s-l96.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/bo8AAOSwxa1g79gK/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/CwEAAOSwuNlg79gL/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/YLkAAOSwqX1g79gL/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/qy0AAOSwrqdg79gK/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/P1kAAOSw7GJg79gL/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/erAAAOSwHGxg9iky/s-l960.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://ir.ebaystatic.com/cr/v/c1/market-sans/v1.0/MarketSans-Regular-WebS.woff2", "Referer=https://ir.ebaystatic.com/rs/c/inception-YHWZhNzc.css", ENDITEM, 
		"Url=https://ir.ebaystatic.com/cr/v/c1/market-sans/v1.0/MarketSans-SemiBold-WebS.woff2", "Referer=https://ir.ebaystatic.com/rs/c/inception-YHWZhNzc.css", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/S5gAAOSwnhVgqLp-/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/k6wAAOSwa4NfXA4b/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/MooAAOSwCydgyppy/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/5XQAAOSwjxVgqjKu/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/l6wAAOSwh7tZtgL0/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://content-autofill.googleapis.com/v1/pages/Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRIeCXiZuWOwTdkMEgUNx46y2RIFDZFhlU4SBQ0nFKMJ?alt=proto", "Referer=", ENDITEM, 
		"Url=https://rover.ebay.com.au/roverimp/0/0/9?imp=2046301&trknvp=cp%3D2380057%26ghi%3D98&1626747595300", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/3ZsAAOSwZJhg8NHw/s-l960.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/CysAAOSw3rFfgWcL/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/DXoAAOSwgvdgRpln/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/8KEAAOSwlVxg9TrQ/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/m78AAOSwjhdftj2u/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/-KIAAOSwJHJg9gt6/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://ir.ebaystatic.com/rs/c/scandal/ScandalJS-2.1.31.min.js", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/YloAAOSw0fNgz0wk/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/or8AAOSwDYJgRmPM/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/Dw4AAOSw3rhg26iL/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://srv.au.ebayrtm.com/rtm?RtmCmd&a=json&uf=0&g=c1b666c317a0a4d6b0caaf40ffff8417&cg=0&c=1H4sIAAAAAAAAAzWPy2rDMBBF9%2F6KgW4SqOXRw7KaoEXoIqWpu4lLNt0otkpEHEs4Nm769ZVLCgN37oUzj4fSd%2FA6tkCfgCGjUVexcgHbskqxQIRF6cduMK6D%2FWC6xvQNVO5il0ngSmpMAsu5vkXHUZf%2Bx7WtyXISuYPrGj9d4b0CSfgaopdiDd9SLGETQmsP9rhzQ5bzgnAJi91LVb49QuvOFra2PvslPJ96f7GZKggSwRQSKWFvvkzv7lQSKNM0T4Lg9K7%2FnmvbpZuPuRVzVLtGc%2FU5IiKNR8cwjUoV14wrxLyYTRzCEOdnmD4NQ7iusmyaJmKP5kZqfyFmzObHiz%2BYz0ulIlQgiSwRyS84pa%2BVUAEAAA%3D%3D&p=1650&di="
		"1650&v=4&enc=UTF-8&cb=window.HL_AD_TRACKING_CALLBACK", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/o74AAOSwXqxd~taX/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/~HAAAOSwkC5g8Rw8/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/wLoAAOSwW8Rg8OWU/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url={URL}.au/sw.js", "Referer={URL}.au/", ENDITEM, 
		"Url=https://ocsrest.ebay.com.au/ocsrsapp/o2/inflow/inflowcomponent?input=%7B%22pageId%22%3A2387624%2C%22surveyTitle%22%3A%22Tell%20us%20what%20you%20think%22%2C%22posTop%22%3A504%7D&callback=Inflow.cb", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/i3IAAOSwqxNg9T2D/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/cqIAAOSwmMtg7rfM/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/~vAAAOSw-qpg9Vpz/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/s4UAAOSwPoFg9g3c/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/o3AAAOSwER1gFQTg/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/6WsAAOSwACdg1AF6/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/880AAOSwVJJf25jb/s-l225.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://srv.au.ebayrtm.com/rtm?RtmCmd&a=json&uf=0&g=c1b666c317a0a4d6b0caaf40ffff8417&cg=0&c=1H4sIAAAAAAAAAzWPy2rDMBBF9%2F6KgW4SqOXRw7KaoEXoIqWpu4lLNt0otkpEHEs4Nm769ZVLCgN37oUzj4fSd%2FA6tkCfgCGjUVexcgHbskqxQIRF6cduMK6D%2FWC6xvQNVO5il0ngSmpMAsu5vkXHUZf%2Bx7WtyXISuYPrGj9d4b0CSfgaopdiDd9SLGETQmsP9rhzQ5bzgnAJi91LVb49QuvOFra2PvslPJ96f7GZKggSwRQSKWFvvkzv7lQSKNM0T4Lg9K7%2FnmvbpZuPuRVzVLtGc%2FU5IiKNR8cwjUoV14wrxLyYTRzCEOdnmD4NQ7iusmyaJmKP5kZqfyFmzObHiz%2BYz0ulIlQgiSwRyS84pa%2BVUAEAAA%3D%3D&p=19392"
		":19393:19394:19395:19396:19397:19398:19399:19400:19401:20858&di=19392:19393:19394:19395:19396:19397:19398:19399:19400:19401:20858&v=4&enc=UTF-8&cb=window.HL_CAT_NAV_RTM_CALLBACK", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/cTIAAOSwe7hg7EJk/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/00/z/bx0AAOSwIzVg657p/$_58.jpg", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/00/s/MTQzNFgxNjAw/z/qCwAAOSw7Z5g657w/$_137.JPG", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/s1wAAOSwpsFg7EJi/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://cs.ns1p.net/p.js?a=c4cra1", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/mD8AAOSwPjRg7EJi/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://ir.ebaystatic.com/cr/v/c1/globalheader_widget_platform__v2-b70676194b.js", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/-5IAAOSwespg7EJj/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/tlgAAOSwJ8Jg7EJj/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/et4AAOSwqX1g7EJk/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://ir.ebaystatic.com/rs/v/5lsr5byiue52tlsfjotewpsxsil.js", "Referer={URL}.au/", ENDITEM, 
		"Url={URL}/nap/napkinapi/v1/ticketing/redeem?ticket=20b9e5f374284da8884c61b8c7caa089", "Referer={URL}.au/", ENDITEM, 
		"Url=https://pages.ebay.com/favicon.ico", "Referer={URL}.au/", ENDITEM, 
		"Url=https://svcs.ebay.com/delstats/imp/rtm?p=100001&mc="
		"YnM9MTV8dD0xNXx0ZHQ9aWlkOjMxNzgyNDY2MDQ1NjYyMzkwMTksY2xraWQ6MzE3ODI0NjYwNDU2NjIzOTAxOHxidz1MQVJHRXxwbG10PShjaGFubmVsOm51bGwgY2lkOjU0MjE0IGdiaDogaWlkOjMxNzgyNDY2MDQ1NjYyMzkwMTkgbWlkOjg2NDc2IHBhZ2VjaTozNDE5MGQzYi1kZWU0LTQ4ZDktODUwMS05YWU3ZTkxOTk1MzkgcGFyZW50cnE6YzFiNjY2OTcxN2EwYTRkNmIwY2QyN2Q4ZmZmZmM2NDIgcGlkOjEwMDAwMSBzaWQ6LTEgdGlkOmIzZTkzZGUxLWUxYmItNDBlMS04NDViLWM2MmZjMWExNmEyMSB0dHlwZTpIT01FX1BBR0VfQkFOTkVSX1ZFTE9DSVRZIHZpZDo5ZjYxMjJhY2Q4ODJkMGYxMDY0MTg2NWJkYmI2NjM4NjI4NWI1Y2EyNDE1MWQyMWVjMjE2NT"
		"BiZWYyNmNhNTY2KXx1bD1lbi1BVXxndWlkPWMxYjY2NmMzMTdhMGE0ZDZiMGNhYWY0MGZmZmY4NDE3fG09ODY0NzZ8bW9idHJrSWQ9Y2VmZjliNjYtOWRlMS00ZGI5LTgyNWQtN2U0MWQ5YmNjYjZjfnNBaTZoTThKbVlVTkh3VDhPdlFHZUxqOWpPNFNlV21QajNSeVNjaWdUamh+R0VtV3pSdFFSVVBPczc3QVFxa0E2MlhSQm00WGpnNE13UHFkRXV4bmFwWnx1Yz0xNQ==", "Referer={URL}.au/", ENDITEM, 
		"Url=https://svcs.ebay.com/delstats/imp/rtm?p=100004&mc="
		"YnM9MTV8dD0xNXx0ZHQ9aWlkOjMxNzgyNDY2MDQxODQwNTUxMTUsY2xraWQ6MzE3ODI0NjYwNDQ1MjQ5MDU3MHxidz1MQVJHRXxwbG10PShjaGFubmVsOm51bGwgY2lkOjU0NzEwIGdiaDogaWlkOjMxNzgyNDY2MDQxODQwNTUxMTUgbWlkOjg3NDY1IHBhZ2VjaToyYTgxZTUxYS01MmZlLTQzYTAtYWRkNC1kZDJiOTMxNTI0YTIgcGFyZW50cnE6YzFiNjY2OTcxN2EwYTRkNmIwY2QyN2Q4ZmZmZmM2NDIgcGlkOjEwMDAwNCBzaWQ6MzcwIHRpZDpiYzhmN2ViZC1jYjBkLTQyYTItODA3Zi0xYzMxODE3NjdiYjYgdHR5cGU6SE9NRV9QQUdFX0JBTk5FUl9WRUxPQ0lUWSB2aWQ6ZTJhZDVhZjExZGE4ZmY3YmYzZDllNjJmMTI2ZWNlZWQxODViZjYxYjA1YmI0NDUxNzNhZG"
		"Y1MWNlMWQ1ZGZmNyl8dWw9ZW4tQVV8Z3VpZD1jMWI2NjZjMzE3YTBhNGQ2YjBjYWFmNDBmZmZmODQxN3xtPTg3NDY1fG1vYnRya0lkPWNlZmY5YjY2LTlkZTEtNGRiOS04MjVkLTdlNDFkOWJjY2I2Y35zQWk2aE04Sm1ZVU5Id1Q4T3ZRR2VMajlqTzRTZVdtUGozUnlTY2lnVGpofkdFbVd6UnRRUlVQT3M3N0FRcWtBNjJYUkJtNFhqZzRNd1BxZEV1eG5hcFp8dWM9MTU=", "Referer={URL}.au/", ENDITEM, 
		"Url=https://ir.ebaystatic.com/rs/c/9527tracking/configuration.js?ts=5422492", "Referer={URL}.au/", ENDITEM, 
		"Url=https://www.googletagservices.com/tag/js/gpt.js", "Referer={URL}.au/", ENDITEM, 
		"Url=https://s.ns1p.net/?v=1619458322&a=c4cra1", "Referer={URL}.au/", ENDITEM, 
		"Url=https://securepubads.g.doubleclick.net/gpt/pubads_impl_2021071502.js?31061831", "Referer={URL}.au/", ENDITEM, 
		"Url=https://backstory.ebay.com.au/customer/v1/customer_image_service?pld="
		"%5B%7B%22guid%22%3A%22c1b666c317a0a4d6b0caaf40ffff8417%22%2C%22eventFamily%22%3A%22AUTO_TRACKING%22%2C%22agentVersion%22%3A%222.0.1%22%2C%22trackable%22%3A%7B%22trackableId%22%3A%22578f485c-35ab-4a89-b051-6ed928ee47c5%22%2C%22parentTrackableId%22%3Anull%2C%22instanceId%22%3A%22https%3A%2F%2Fwww.ebay.com.au%2F%22%2C%22screenId%22%3A%2282021922-eb3c-49dd-8576-b38c70a1db17%22%2C%22description%22%3A%22Electronics%2C%20Cars%2C%20Fashion%2C%20Collectibles%20%26%20More%20%7C%20eBay%22%2C%22entityId%22%3A"
		"%222481888%22%2C%22correlationId%22%3A%22f89ad337-e900-11eb-8d6d-7650a8cd509a%22%2C%22entityType%22%3A%22Page%22%7D%2C%22activity%22%3A%7B%22timestamp%22%3A1626747612179%2C%22category%22%3A%22Impression%22%2C%22type%22%3A%22VIEW.PAGE_LOAD%22%2C%22referer%22%3A%22%22%2C%22details%22%3A%7B%22ePageId%22%3A%222481888%22%2C%22nPageId%22%3A%222380057%22%7D%2C%22viewportWidth%22%3A1920%2C%22viewportHeight%22%3A969%7D%2C%22context%22%3A%7B%22utcOffset%22%3A-10%2C%22userLang%22%3A%22en-US%22%2C%22userAgent"
		"%22%3A%22Mozilla%2F5.0%20(Windows%20NT%206.3%3B%20Win64%3B%20x64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F87.0.4280.66%20Safari%2F537.36%22%2C%22screenWidth%22%3A1920%2C%22screenHeight%22%3A1080%2C%22others%22%3A%7B%7D%7D%7D%5D&ct=1626747612187", "Referer={URL}.au/", ENDITEM, 
		"Url=https://i.ebayimg.com/images/g/kI4AAOSwI3lg7EJf/s-l200.webp", "Referer={URL}.au/", ENDITEM, 
		"Url=https://akamai-static.ebaycdn.net/images/g/gY4AAOSwNkxa2hpY/s-l500.jpg?t=be1dxf", "Referer={URL}.au/", ENDITEM, 
		"Url=https://akamai-static.ebaycdn.net/images/g/gY4AAOSwNkxa2hpY/s-l500.jpg?t=uf0bcg", "Referer={URL}.au/", ENDITEM, 
		"Url=https://akamai-static.ebaycdn.net/images/g/gY4AAOSwNkxa2hpY/s-l500.jpg?t=8ip9po", "Referer={URL}.au/", ENDITEM, 
		"Url=https://b.ns1p.net/?v=1619458322&x=7towbv&r=c4cra1,s3x4pb,125c00u:ii2,0,12y|ii2,0,12x|ii2,0,12w", "Referer={URL}.au/", ENDITEM, 
		"Url=https://ir.ebaystatic.com/rs/v/dxtuvtkk2q3hpkc1xveeo13iaek.js", "Referer={URL}.au/", ENDITEM, 
		"Url=https://ir.ebaystatic.com/rs/c/desk20210513_1.js", "Referer={URL}.au/", ENDITEM, 
		"Url=https://securepubads.g.doubleclick.net/gampad/ads?gdfp_req=1&pvsid=2698852531027382&correlator=2129365219772483&output=ldjh&impl=fif&eid=31060439%2C31061805%2C31061831%2C21064370%2C31061498%2C20211866%2C21067496&vrg=2021071502&ptt=17&sc=1&sfv=1-0-38&ecs=20210720&iu_parts=2455%2Cebay.au.homepage.cchp%2Ccchp&enc_prev_ius=%2F0%2F1%2F2&prev_iu_szs=970x90%7C728x90&fsfs=1&prev_scp="
		"ap%3DScandal%26g%3Dc1b666c317a0a4d6b0caaf40ffff8417%26us%3D13%26ot%3D1%26pr%3D20%26xp%3D20%26np%3D20%26u%3D9b1be96729284d35adebe16be24f340d%26ipp%3D0%26iccr%3D0%26gdprUser%3D0%26plmtid%3D100712%26acc%3Dext&cookie_enabled=1&bc=31&abxe=1&lmt=1626747626&dt=1626747626009&dlt=1626747594427&idt=27164&frm=20&biw=1903&bih=969&oid=3&adxs=0&adys=526&adks=666316433&ucis=1&ifi=1&u_tz=600&u_his=1&u_java=false&u_h=1080&u_w=1920&u_ah=1040&u_aw=1920&u_cd=24&u_nmime=4&u_sd=1&flash=0&url="
		"https%3A%2F%2Fwww.ebay.com.au%2F&vis=1&dmc=8&scr_x=0&scr_y=0&psz=1903x0&msz=970x-1&ga_vid=1725674302.1626747626&ga_sid=1626747626&ga_hid=306473595&ga_fc=false&fws=4&ohw=970&btvi=0", "Referer={URL}.au/", ENDITEM, 
		"Url=https://www.googletagservices.com/activeview/js/current/osd.js", "Referer={URL}.au/", ENDITEM, 
		"Url=https://securepubads.g.doubleclick.net/gampad/ads?gdfp_req=1&pvsid=2698852531027382&correlator=2129365219772483&output=ldjh&impl=fif&eid=31060439%2C31061805%2C31061831%2C21064370%2C31061498%2C20211866%2C21067496&vrg=2021071502&ptt=17&sc=1&sfv=1-0-38&ecs=20210720&iu_parts=2455%2Cebay.au.homepage.cchp%2Cbtf1&enc_prev_ius=%2F0%2F1%2F2&prev_iu_szs=300x250&fsfs=1&prev_scp="
		"ap%3DScandal%26g%3Dc1b666c317a0a4d6b0caaf40ffff8417%26us%3D13%26ot%3D1%26pr%3D20%26xp%3D20%26np%3D20%26u%3D20b9e5f374284da8884c61b8c7caa089%26ipp%3D0%26iccr%3D0%26gdprUser%3D0%26plmtid%3D100716%26acc%3Dext%26to_pb%3Dnobid%26to_bidder%3Dnobid%26to_adid%3Dnobid%26to_adsize%3Dnobid%26refresh%3D0%26rcount%3D0&cookie_enabled=1&bc=31&abxe=1&lmt=1626747626&dt=1626747626078&dlt=1626747594427&idt=27164&frm=20&biw=1903&bih=969&oid=3&adxs=1276&adys=2075&adks=2590623213&ucis=3&ifi=3&u_tz=600&u_his=1&u_java="
		"false&u_h=1080&u_w=1920&u_ah=1040&u_aw=1920&u_cd=24&u_nmime=4&u_sd=1&flash=0&url=https%3A%2F%2Fwww.ebay.com.au%2F&vis=1&dmc=8&scr_x=0&scr_y=0&psz=300x0&msz=300x0&ga_vid=1725674302.1626747626&ga_sid=1626747626&ga_hid=306473595&ga_fc=false&fws=4&ohw=300&btvi=1", "Referer={URL}.au/", ENDITEM, 
		"Url=https://securepubads.g.doubleclick.net/gampad/ads?gdfp_req=1&pvsid=2698852531027382&correlator=2129365219772483&output=ldjh&impl=fif&eid=31060439%2C31061805%2C31061831%2C21064370%2C31061498%2C20211866%2C21067496&vrg=2021071502&ptt=17&sc=1&sfv=1-0-38&ecs=20210720&iu_parts=2455%2Cebay.au.homepage.cchp%2Ccchp&enc_prev_ius=%2F0%2F1%2F2&prev_iu_szs=970x30&fsfs=1&prev_scp="
		"ap%3DScandal%26g%3Dc1b666c317a0a4d6b0caaf40ffff8417%26us%3D13%26ot%3D1%26pr%3D20%26xp%3D20%26np%3D20%26u%3D3c95209c376846e799de80f52ed79f51%26ipp%3D0%26iccr%3D0%26gdprUser%3D0%26plmtid%3D100713%26acc%3Dext&cookie_enabled=1&bc=31&abxe=1&lmt=1626747626&dt=1626747626051&dlt=1626747594427&idt=27164&frm=20&biw=1903&bih=969&oid=3&adxs=0&adys=0&adks=3532893633&ucis=2&ifi=2&u_tz=600&u_his=1&u_java=false&u_h=1080&u_w=1920&u_ah=1040&u_aw=1920&u_cd=24&u_nmime=4&u_sd=1&flash=0&url="
		"https%3A%2F%2Fwww.ebay.com.au%2F&vis=1&dmc=8&scr_x=0&scr_y=0&psz=1903x0&msz=1903x0&ga_vid=1725674302.1626747626&ga_sid=1626747626&ga_hid=306473595&ga_fc=false&fws=0&ohw=0&btvi=0", "Referer={URL}.au/", ENDITEM, 
		"Url=https://adservice.google.com/adsid/integrator.js?domain=www.ebay.com.au", "Referer={URL}.au/", ENDITEM, 
		"Url=https://rover.ebay.com.au/roverimp/0/0/9?imp=2046301&trknvp=cp%3D2547031%26ghi%3D98&1626747626239", "Referer={URL}.au/", ENDITEM, 
		"Url=https://tpc.googlesyndication.com/sodar/sodar2.js", "Referer={URL}.au/", ENDITEM, 
		"Url=https://rover.ebay.com.au/roverclk/0/0/9?trknvp=sid%3Dp2481888.m1383.l6435%26ts%3D1626747631470", "Referer={URL}.au/", ENDITEM, 
		"Url=https://pagead2.googlesyndication.com/pagead/gen_204?id=sodar2&v=224&t=2&li=gpt_2021071502&jk=2698852531027382&bg="
		"!ODulO3_NAAZjFomlYxY7ACkAdvg8WoSltZ3ta3Z6OxJxRRrqOS_Ie9t3I0JE218zAagzknYBhAjOtAIAAAEHUgAAAA5oAQcKAD3UivA8TbkHiH4zBPf3vEySzWBbq4O3hF7igAg_dWhDkTBsBCiosDAJ6Cy1HAkDoE7PtFRsH9mm84i5mc_0mQKTS8iGin6epOTQEUclVLOt--h98dUAwf0GbqKyX9Li-jWqGU7k9QVZf6cM_ICzfH7oxrs6TYzsPNz3AHXdNoqN-gQ4-j2ENvCdpGz9pT3cwoPRJJu1yzypcq9dS_bj_VCBVZUOH-SQZUTJSLYvJzpYoQsurRgAv-lV_NmroyR5KpNKbPTlp8hVRqygGbgX8xjimrdsCWv4jCqQZXenZNPKuUz6Gey1hi_c3TL_673P5_lWzWrZ-Gi5BZijleNfQ5gEUAqrsL865mYYeZH02LR-cNJLHx79P-z8OcidwAq9we8b6zI64jsGvfo2E7Geu"
		"3f5-LDmYX6JyzxG_Rsee0H6j8DBemUHk8RIHrwBTmvmcpLMuV9iiynfRER1VClIScoO43UeT--iBhl0W2Rmq9Wg53-09nNSak2C_7WycoUPblZfXfzklEj0iRbcKNYKR4DMyiA5QQQSiVgK4zK8RqRZlCPpsiDNKQubIdZ36NGX2LMCP0vRXDEYy54DEQf1B7cVbLCD7Ovmc0ecc0gTWF3rbiLktJCrTdpKhti5O_hune45-GA5rRds9vCgZcQWGYPpmuk_ExYwQ7su7O2-Z5Qg-jOO6p3rSBNrem_ynvUPzm5ppe0mgMLIgMXu_JpfHOyFDwopOfYeVJ-MNnJzPazKwTM1de4U9HfxuZFMTIpiMQvgGGnl5L06jeCBASzVfAFz_PAlrAlUx-EgvJAXwfcUhIpDrKYen7utZfwf1oQoY4AX0kbzmE6hJc4pQuwhphWj-8Nk3JqWkxj9w87i0UXOYU8Ed8JEwXbIRq4uqNHhEpYhCYOoNns"
		"BklIzZ0UcxhRSMl5rXssYrpHhb_w5q7DX1AurTZe8JuyzfnEHHV8SxwnDShU", "Referer={URL}.au/", ENDITEM, 
		"Url=https://rover.ebay.com.au/roverimp/0/0/9?imp=2046301&trknvp=cp%3D2547031%26ghi%3D98&1626747754590", "Referer={URL}.au/", ENDITEM, 
		LAST);

	web_add_header("Access-Control-Request-Method", 
		"GET");

	web_add_header("Access-Control-Request-Headers", 
		"ufes-cache-key");

	web_add_auto_header("Origin", 
		"{URL}.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_custom_request("redeem",
		"URL={URL}/nap/napkinapi/v1/ticketing/redeem?ticket={C_ticket}",
		"Method=OPTIONS",
		"Resource=0",
		"Referer={URL}.au/",
		"Snapshot=t13.inf",
		"Mode=HTML",
		LAST);

	lr_end_transaction("S01_AddItemtoCart_T10_Homepage",LR_AUTO);

	lr_think_time(thinktime);
	
	return 0;
}
