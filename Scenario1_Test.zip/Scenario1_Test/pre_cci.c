# 1 "c:\\scripts_backup\\scenario1_test\\\\combined_Scenario1_Test.c"
# 1 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h" 1
 
 












 











# 103 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"





















































		


		typedef unsigned size_t;
	
	
        
	

















	

 



















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);
int   lr_start_cross_vuser_transaction		(char * transaction_name, char * trans_id_param); 



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);
int   lr_end_cross_vuser_transaction	(char * transaction_name, char * trans_id_param, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 273 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_unmask (const char *EncodedString);
char *   lr_decrypt (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 513 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 516 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 540 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 574 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 597 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 621 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);



int   lr_set_custom_error_message (const char * param_val, ...);

int   lr_remove_custom_error_message ();


int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);
int   lr_save_timestamp (const char * tmstampParam, ...);
int   lr_save_param_regexp (const char *bufferToScan, unsigned int bufSize, ...);

int   lr_convert_double_to_integer (const char *source_param_name, const char * target_param_name);
int   lr_convert_double_to_double (const char *source_param_name, const char *format_string, const char * target_param_name);

 
 
 
 
 
 
# 700 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											size_t * col_name_len);
# 761 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);

 
 
 
 
# 776 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
int   lr_zip (const char* param1, const char* param2);
int   lr_unzip (const char* param1, const char* param2);

 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   size_t const in_len,
                                   char * * const out_str,
                                   size_t * const out_len);
# 800 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 812 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 820 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 826 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );







typedef struct _lr_timestamp_param
{
	int iDigits;
}lr_timestamp_param;

extern const lr_timestamp_param default_timestamp_param;

int   lrfnc_save_timestamp (const char * param_name, const lr_timestamp_param* time_param);

int lr_save_searched_string(char * buffer, long buf_size, unsigned int occurrence,
			    char * search_string, int offset, unsigned int param_val_len, 
			    char * param_name);

 
char *   lr_string (char * str);

 
# 929 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 936 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 958 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 1034 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 1063 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"


# 1075 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 


typedef int PVCI;






typedef int VTCERR;









PVCI   vtc_connect(char * servername, int portnum, int options);
VTCERR   vtc_disconnect(PVCI pvci);
VTCERR   vtc_get_last_error(PVCI pvci);
VTCERR   vtc_query_column(PVCI pvci, char * columnName, int columnIndex, char * *outvalue);
VTCERR   vtc_query_row(PVCI pvci, int rowIndex, char * **outcolumns, char * **outvalues);
VTCERR   vtc_send_message(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_if_unique(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_row1(PVCI pvci, char * columnNames, char * messages, char * delimiter, unsigned char sendflag, unsigned short *outUpdates);
VTCERR   vtc_search_row(PVCI pvci, char * columnNames, char * messages, char * delimiter, char * **outcolumns, char * **outvalues);
VTCERR   vtc_update_message(PVCI pvci, char * column, int index , char * message, unsigned short *outRc);
VTCERR   vtc_update_message_ifequals(PVCI pvci, char * columnName, int index,	char * message, char * ifmessage, unsigned short 	*outRc);
VTCERR   vtc_update_row1(PVCI pvci, char * columnNames, int index , char * messages, char * delimiter, unsigned short *outUpdates);
VTCERR   vtc_retrieve_message(PVCI pvci, char * column, char * *outvalue);
VTCERR   vtc_retrieve_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues);
VTCERR   vtc_retrieve_row(PVCI pvci, char * **outcolumns, char * **outvalues);
VTCERR   vtc_rotate_message(PVCI pvci, char * column, char * *outvalue, unsigned char sendflag);
VTCERR   vtc_rotate_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_rotate_row(PVCI pvci, char * **outcolumns, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_increment(PVCI pvci, char * column, int index , int incrValue, int *outValue);
VTCERR   vtc_clear_message(PVCI pvci, char * column, int index , unsigned short *outRc);
VTCERR   vtc_clear_column(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_ensure_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_drop_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_clear_row(PVCI pvci, int rowIndex, unsigned short *outRc);
VTCERR   vtc_create_column(PVCI pvci, char * column,unsigned short *outRc);
VTCERR   vtc_column_size(PVCI pvci, char * column, int *size);
void   vtc_free(char * msg);
void   vtc_free_list(char * *msglist);
VTCERR   vtc_update_all_message_ifequals(PVCI pvci, char * columnNames, char * message, char * ifmessage, char * delimiter, unsigned short *outRc);

VTCERR   lrvtc_connect(char * servername, int portnum, int options);
VTCERR   lrvtc_connect_ex(char * vtc_first_param, ...);
VTCERR   lrvtc_connect_ex_no_ellipsis(const char *vtc_first_param, char ** arguments, int argCount);
VTCERR   lrvtc_disconnect();
VTCERR   lrvtc_query_column(char * columnName, int columnIndex);
VTCERR   lrvtc_query_row(int columnIndex);
VTCERR   lrvtc_send_message(char * columnName, char * message);
VTCERR   lrvtc_send_if_unique(char * columnName, char * message);
VTCERR   lrvtc_send_row1(char * columnNames, char * messages, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_search_row(char * columnNames, char * messages, char * delimiter);
VTCERR   lrvtc_update_message(char * columnName, int index , char * message);
VTCERR   lrvtc_update_message_ifequals(char * columnName, int index, char * message, char * ifmessage);
VTCERR   lrvtc_update_row1(char * columnNames, int index , char * messages, char * delimiter);
VTCERR   lrvtc_retrieve_message(char * columnName);
VTCERR   lrvtc_retrieve_messages1(char * columnNames, char * delimiter);
VTCERR   lrvtc_retrieve_row();
VTCERR   lrvtc_rotate_message(char * columnName, unsigned char sendflag);
VTCERR   lrvtc_rotate_messages1(char * columnNames, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_rotate_row(unsigned char sendflag);
VTCERR   lrvtc_increment(char * columnName, int index , int incrValue);
VTCERR   lrvtc_noop();
VTCERR   lrvtc_clear_message(char * columnName, int index);
VTCERR   lrvtc_clear_column(char * columnName); 
VTCERR   lrvtc_ensure_index(char * columnName); 
VTCERR   lrvtc_drop_index(char * columnName); 
VTCERR   lrvtc_clear_row(int rowIndex);
VTCERR   lrvtc_create_column(char * columnName);
VTCERR   lrvtc_column_size(char * columnName);
VTCERR   lrvtc_update_all_message_ifequals(char * columnNames, char * message, char * ifmessage, char * delimiter);



 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char * sourceString, char * fromEncoding, char * toEncoding, char * paramName);
int lr_read_file(const char *filename, const char *outputParam, int continueOnError);

int lr_get_char_count(const char * string);


 
int lr_db_connect (char * pFirstArg, ...);
int lr_db_disconnect (char * pFirstArg,	...);
int lr_db_executeSQLStatement (char * pFirstArg, ...);
int lr_db_dataset_action(char * pFirstArg, ...);
int lr_checkpoint(char * pFirstArg,	...);
int lr_db_getvalue(char * pFirstArg, ...);







 
 



















# 1 "c:\\scripts_backup\\scenario1_test\\\\combined_Scenario1_Test.c" 2

# 1 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/SharedParameter.h" 1



 
 
 
 
# 100 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/SharedParameter.h"






typedef int PVCI2;






typedef int VTCERR2;


 
 
 

 
extern PVCI2    vtc_connect(char *servername, int portnum, int options);
extern VTCERR2  vtc_disconnect(PVCI2 pvci);
extern VTCERR2  vtc_get_last_error(PVCI2 pvci);

 
extern VTCERR2  vtc_query_column(PVCI2 pvci, char *columnName, int columnIndex, char **outvalue);
extern VTCERR2  vtc_query_row(PVCI2 pvci, int columnIndex, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_send_message(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_if_unique(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_row1(PVCI2 pvci, char *columnNames, char *messages, char *delimiter,  unsigned char sendflag, unsigned short *outUpdates);
extern VTCERR2  vtc_search_row(PVCI2 pvci, char *columnNames, char *messages, char *delimiter, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_update_message(PVCI2 pvci, char *column, int index , char *message, unsigned short *outRc);
extern VTCERR2  vtc_update_message_ifequals(PVCI2 pvci, char	*columnName, int index,	char *message, char	*ifmessage,	unsigned short 	*outRc);
extern VTCERR2  vtc_update_row1(PVCI2 pvci, char *columnNames, int index , char *messages, char *delimiter, unsigned short *outUpdates);
extern VTCERR2  vtc_retrieve_message(PVCI2 pvci, char *column, char **outvalue);
extern VTCERR2  vtc_retrieve_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues);
extern VTCERR2  vtc_retrieve_row(PVCI2 pvci, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_rotate_message(PVCI2 pvci, char *column, char **outvalue, unsigned char sendflag);
extern VTCERR2  vtc_rotate_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues, unsigned char sendflag);
extern VTCERR2  vtc_rotate_row(PVCI2 pvci, char ***outcolumns, char ***outvalues, unsigned char sendflag);
extern VTCERR2	vtc_increment(PVCI2 pvci, char *column, int index , int incrValue, int *outValue);
extern VTCERR2  vtc_clear_message(PVCI2 pvci, char *column, int index , unsigned short *outRc);
extern VTCERR2  vtc_clear_column(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_clear_row(PVCI2 pvci, int rowIndex, unsigned short *outRc);

extern VTCERR2  vtc_create_column(PVCI2 pvci, char *column,unsigned short *outRc);
extern VTCERR2  vtc_column_size(PVCI2 pvci, char *column, int *size);
extern VTCERR2  vtc_ensure_index(PVCI2 pvci, char *column, unsigned short *outRc);
extern VTCERR2  vtc_drop_index(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_noop(PVCI2 pvci);

 
extern void vtc_free(char *msg);
extern void vtc_free_list(char **msglist);

 


 




 




















 




 
 
 

extern VTCERR2  lrvtc_connect(char *servername, int portnum, int options);
 
 
extern VTCERR2  lrvtc_disconnect();
extern VTCERR2  lrvtc_query_column(char *columnName, int columnIndex);
extern VTCERR2  lrvtc_query_row(int columnIndex);
extern VTCERR2  lrvtc_send_message(char *columnName, char *message);
extern VTCERR2  lrvtc_send_if_unique(char *columnName, char *message);
extern VTCERR2  lrvtc_send_row1(char *columnNames, char *messages, char *delimiter,  unsigned char sendflag);
extern VTCERR2  lrvtc_search_row(char *columnNames, char *messages, char *delimiter);
extern VTCERR2  lrvtc_update_message(char *columnName, int index , char *message);
extern VTCERR2  lrvtc_update_message_ifequals(char *columnName, int index, char 	*message, char *ifmessage);
extern VTCERR2  lrvtc_update_row1(char *columnNames, int index , char *messages, char *delimiter);
extern VTCERR2  lrvtc_retrieve_message(char *columnName);
extern VTCERR2  lrvtc_retrieve_messages1(char *columnNames, char *delimiter);
extern VTCERR2  lrvtc_retrieve_row();
extern VTCERR2  lrvtc_rotate_message(char *columnName, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_messages1(char *columnNames, char *delimiter, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_row(unsigned char sendflag);
extern VTCERR2  lrvtc_increment(char *columnName, int index , int incrValue);
extern VTCERR2  lrvtc_clear_message(char *columnName, int index);
extern VTCERR2  lrvtc_clear_column(char *columnName);
extern VTCERR2  lrvtc_clear_row(int rowIndex);
extern VTCERR2  lrvtc_create_column(char *columnName);
extern VTCERR2  lrvtc_column_size(char *columnName);
extern VTCERR2  lrvtc_ensure_index(char *columnName);
extern VTCERR2  lrvtc_drop_index(char *columnName);

extern VTCERR2  lrvtc_noop();

 
 
 

                               


 
 
 





















# 2 "c:\\scripts_backup\\scenario1_test\\\\combined_Scenario1_Test.c" 2

# 1 "globals.h" 1



 
 

# 1 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/web_api.h" 1







# 1 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/as_web.h" 1



























































 




 



 











 





















 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_pac(
		const char *		mpszPacUrl);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	spdy_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_json(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_regexp(
		 const char * mpszParamName,
		 ...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_attrib(
		const char * mpszParamName,
		...);
										 
										 
										 
										 
										 
										 
										 		
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_run(
		const char * mpszCode,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_reset(void);

  int
	web_convert_date_param(
		const char * 		mpszParamName,
		...);










# 789 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/as_web.h"


# 802 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/as_web.h"



























# 840 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 908 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/as_web.h"


  int
	web_rest(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 

  int
web_stream_open(
	const char *		mpszArg1,
	...
);
  int
	web_stream_wait(
		const char *		mpszArg1,
		...
	);

  int
	web_stream_close(
		const char *		mpszArg1,
		...
	);

  int
web_stream_play(
	const char *		mpszArg1,
	...
	);

  int
web_stream_pause(
	const char *		mpszArg1,
	...
	);

  int
web_stream_seek(
	const char *		mpszArg1,
	...
	);

  int
web_stream_get_param_int(
	const char*			mpszStreamID,
	const int			miStateType
	);

  double
web_stream_get_param_double(
	const char*			mpszStreamID,
	const int			miStateType
	);

  int
web_stream_get_param_string(
	const char*			mpszStreamID,
	const int			miStateType,
	const char*			mpszParameterName
	);

  int
web_stream_set_param_int(
	const char*			mpszStreamID,
	const int			miStateType,
	const int			miStateValue
	);

  int
web_stream_set_param_double(
	const char*			mpszStreamID,
	const int			miStateType,
	const double		mdfStateValue
	);

  int
web_stream_set_custom_mpd(
	const char*			mpszStreamID,
	const char*			aMpdBuf
	);

 
 
 






# 9 "C:\\Program Files (x86)\\HP\\LoadRunner\\include/web_api.h" 2

















 







 















  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

 
 
 
 
 
 
 
 
 
 
 
 
  int
	web_reg_async_attributes(
		const char *		mpszArg,
		...
	);

 
 
 
 
 
 
  int
	web_sync(
		 const char *		mpszArg1,
		 ...
	);

 
 
 
 
  int
	web_stop_async(
		const char *		mpszArg1,
		...
	);

 
 
 
 
 

 
 
 

typedef enum WEB_ASYNC_CB_RC_ENUM_T
{
	WEB_ASYNC_CB_RC_OK,				 

	WEB_ASYNC_CB_RC_ABORT_ASYNC_NOT_ERROR,
	WEB_ASYNC_CB_RC_ABORT_ASYNC_ERROR,
										 
										 
										 
										 
	WEB_ASYNC_CB_RC_ENUM_COUNT
} WEB_ASYNC_CB_RC_ENUM;

 
 
 

typedef enum WEB_CONVERS_CB_CALL_REASON_ENUM_T
{
	WEB_CONVERS_CB_CALL_REASON_BUFFER_RECEIVED,
	WEB_CONVERS_CB_CALL_REASON_END_OF_TASK,

	WEB_CONVERS_CB_CALL_REASON_ENUM_COUNT
} WEB_CONVERS_CB_CALL_REASON_ENUM;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

typedef
int														 
	(*RequestCB_t)();

typedef
int														 
	(*ResponseBodyBufferCB_t)(
		  const char *		aLastBufferStr,
		  int				aLastBufferLen,
		  const char *		aAccumulatedStr,
		  int				aAccumulatedLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseCB_t)(
		  const char *		aResponseHeadersStr,
		  int				aResponseHeadersLen,
		  const char *		aResponseBodyStr,
		  int				aResponseBodyLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseHeadersCB_t)(
		  int				aHttpStatusCode,
		  const char *		aAccumulatedHeadersStr,
		  int				aAccumulatedHeadersLen);



 
 
 

typedef enum WEB_CONVERS_UTIL_RC_ENUM_T
{
	WEB_CONVERS_UTIL_RC_OK,
	WEB_CONVERS_UTIL_RC_CONVERS_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_TASK_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_UNAVIALABLE,
	WEB_CONVERS_UTIL_RC_INVALID_ARGUMENT,

	WEB_CONVERS_UTIL_RC_ENUM_COUNT
} WEB_CONVERS_UTIL_RC_ENUM;

 
 
 

  int					 
	web_util_set_request_url(
		  const char *		aUrlStr);

  int					 
	web_util_set_request_body(
		  const char *		aRequestBodyStr);

  int					 
	web_util_set_formatted_request_body(
		  const char *		aRequestBodyStr);


 
 
 
 
 

 
 
 
 
 

 
 
 
 
 
 
 
 

 
 
  int
web_websocket_connect(
		 const char *	mpszArg1,
		 ...
		 );


 
 
 
 
 																						
  int
web_websocket_send(
	   const char *		mpszArg1,
		...
	   );

 
 
 
 
 
 
  int
web_websocket_close(
		const char *	mpszArg1,
		...
		);

 
typedef
void														
(*OnOpen_t)(
			  const char* connectionID,  
			  const char * responseHeader,  
			  int length  
);

typedef
void														
(*OnMessage_t)(
	  const char* connectionID,  
	  int isbinary,  
	  const char * data,  
	  int length  
	);

typedef
void														
(*OnError_t)(
	  const char* connectionID,  
	  const char * message,  
	  int length  
	);

typedef
void														
(*OnClose_t)(
	  const char* connectionID,  
	  int isClosedByClient,  
	  int code,  
	  const char* reason,  
	  int length  
	 );
 
 
 
 
 





# 7 "globals.h" 2

# 1 "lrw_custom_body.h" 1
 




# 8 "globals.h" 2


 
 



int thinktime = 5;
# 3 "c:\\scripts_backup\\scenario1_test\\\\combined_Scenario1_Test.c" 2

# 1 "vuser_init.c" 1
vuser_init()
{
	
	 
# 43 "vuser_init.c"
	
	
	web_set_sockets_option("SSL_VERSION", "AUTO");
		
		
	web_reg_save_param("C_ticket", "LB=ammiid\":\"", "RB=\"","ord=1", "LAST");	
	

lr_start_transaction("S01_AddItemtoCart_T10_Homepage");
		
		
	web_url("ebay.com.au", 
		"URL=https://ebay.com.au/", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=https://ir.ebaystatic.com/pictures/aw/pics/cmp/ds3/sprds3_20.png", "Referer=https://ir.ebaystatic.com/rs/v/vd0fjlgwua5qnokbp5vgu1p33az.css?proc=DU:N", "ENDITEM", 
		"Url=https://ir.ebaystatic.com/rs/v/acxp0mbuba3zva1qr31idsmitmi.png", "Referer=https://ir.ebaystatic.com/rs/v/vd0fjlgwua5qnokbp5vgu1p33az.css?proc=DU:N", "ENDITEM", 
		"Url=https://i.ebayimg.com/00/s/MzZYNDI=/z/BGEAAOSw8FRZqY4x/$_57.PNG", "Referer=https://ir.ebaystatic.com/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/ewgAAOSwCl5g79gL/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/YEcAAOSw-jlg79gL/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/kigAAOSwPM9g8NOe/s-l96.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/bo8AAOSwxa1g79gK/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/CwEAAOSwuNlg79gL/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/YLkAAOSwqX1g79gL/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/qy0AAOSwrqdg79gK/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/P1kAAOSw7GJg79gL/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/erAAAOSwHGxg9iky/s-l960.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://ir.ebaystatic.com/cr/v/c1/market-sans/v1.0/MarketSans-Regular-WebS.woff2", "Referer=https://ir.ebaystatic.com/rs/c/inception-YHWZhNzc.css", "ENDITEM", 
		"Url=https://ir.ebaystatic.com/cr/v/c1/market-sans/v1.0/MarketSans-SemiBold-WebS.woff2", "Referer=https://ir.ebaystatic.com/rs/c/inception-YHWZhNzc.css", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/S5gAAOSwnhVgqLp-/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/k6wAAOSwa4NfXA4b/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/MooAAOSwCydgyppy/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/5XQAAOSwjxVgqjKu/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/l6wAAOSwh7tZtgL0/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://content-autofill.googleapis.com/v1/pages/Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRIeCXiZuWOwTdkMEgUNx46y2RIFDZFhlU4SBQ0nFKMJ?alt=proto", "Referer=", "ENDITEM", 
		"Url=https://rover.ebay.com.au/roverimp/0/0/9?imp=2046301&trknvp=cp%3D2380057%26ghi%3D98&1626747595300", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/3ZsAAOSwZJhg8NHw/s-l960.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/CysAAOSw3rFfgWcL/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/DXoAAOSwgvdgRpln/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/8KEAAOSwlVxg9TrQ/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/m78AAOSwjhdftj2u/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/-KIAAOSwJHJg9gt6/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://ir.ebaystatic.com/rs/c/scandal/ScandalJS-2.1.31.min.js", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/YloAAOSw0fNgz0wk/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/or8AAOSwDYJgRmPM/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/Dw4AAOSw3rhg26iL/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://srv.au.ebayrtm.com/rtm?RtmCmd&a=json&uf=0&g=c1b666c317a0a4d6b0caaf40ffff8417&cg=0&c=1H4sIAAAAAAAAAzWPy2rDMBBF9%2F6KgW4SqOXRw7KaoEXoIqWpu4lLNt0otkpEHEs4Nm769ZVLCgN37oUzj4fSd%2FA6tkCfgCGjUVexcgHbskqxQIRF6cduMK6D%2FWC6xvQNVO5il0ngSmpMAsu5vkXHUZf%2Bx7WtyXISuYPrGj9d4b0CSfgaopdiDd9SLGETQmsP9rhzQ5bzgnAJi91LVb49QuvOFra2PvslPJ96f7GZKggSwRQSKWFvvkzv7lQSKNM0T4Lg9K7%2FnmvbpZuPuRVzVLtGc%2FU5IiKNR8cwjUoV14wrxLyYTRzCEOdnmD4NQ7iusmyaJmKP5kZqfyFmzObHiz%2BYz0ulIlQgiSwRyS84pa%2BVUAEAAA%3D%3D&p=1650&di="
		"1650&v=4&enc=UTF-8&cb=window.HL_AD_TRACKING_CALLBACK", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/o74AAOSwXqxd~taX/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/~HAAAOSwkC5g8Rw8/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/wLoAAOSwW8Rg8OWU/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url={URL}.au/sw.js", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://ocsrest.ebay.com.au/ocsrsapp/o2/inflow/inflowcomponent?input=%7B%22pageId%22%3A2387624%2C%22surveyTitle%22%3A%22Tell%20us%20what%20you%20think%22%2C%22posTop%22%3A504%7D&callback=Inflow.cb", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/i3IAAOSwqxNg9T2D/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/cqIAAOSwmMtg7rfM/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/~vAAAOSw-qpg9Vpz/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/s4UAAOSwPoFg9g3c/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/o3AAAOSwER1gFQTg/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/6WsAAOSwACdg1AF6/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/880AAOSwVJJf25jb/s-l225.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://srv.au.ebayrtm.com/rtm?RtmCmd&a=json&uf=0&g=c1b666c317a0a4d6b0caaf40ffff8417&cg=0&c=1H4sIAAAAAAAAAzWPy2rDMBBF9%2F6KgW4SqOXRw7KaoEXoIqWpu4lLNt0otkpEHEs4Nm769ZVLCgN37oUzj4fSd%2FA6tkCfgCGjUVexcgHbskqxQIRF6cduMK6D%2FWC6xvQNVO5il0ngSmpMAsu5vkXHUZf%2Bx7WtyXISuYPrGj9d4b0CSfgaopdiDd9SLGETQmsP9rhzQ5bzgnAJi91LVb49QuvOFra2PvslPJ96f7GZKggSwRQSKWFvvkzv7lQSKNM0T4Lg9K7%2FnmvbpZuPuRVzVLtGc%2FU5IiKNR8cwjUoV14wrxLyYTRzCEOdnmD4NQ7iusmyaJmKP5kZqfyFmzObHiz%2BYz0ulIlQgiSwRyS84pa%2BVUAEAAA%3D%3D&p=19392"
		":19393:19394:19395:19396:19397:19398:19399:19400:19401:20858&di=19392:19393:19394:19395:19396:19397:19398:19399:19400:19401:20858&v=4&enc=UTF-8&cb=window.HL_CAT_NAV_RTM_CALLBACK", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/cTIAAOSwe7hg7EJk/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/00/z/bx0AAOSwIzVg657p/$_58.jpg", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/00/s/MTQzNFgxNjAw/z/qCwAAOSw7Z5g657w/$_137.JPG", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/s1wAAOSwpsFg7EJi/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://cs.ns1p.net/p.js?a=c4cra1", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/mD8AAOSwPjRg7EJi/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://ir.ebaystatic.com/cr/v/c1/globalheader_widget_platform__v2-b70676194b.js", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/-5IAAOSwespg7EJj/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/tlgAAOSwJ8Jg7EJj/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/et4AAOSwqX1g7EJk/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://ir.ebaystatic.com/rs/v/5lsr5byiue52tlsfjotewpsxsil.js", "Referer={URL}.au/", "ENDITEM", 
		"Url={URL}/nap/napkinapi/v1/ticketing/redeem?ticket=20b9e5f374284da8884c61b8c7caa089", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://pages.ebay.com/favicon.ico", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://svcs.ebay.com/delstats/imp/rtm?p=100001&mc="
		"YnM9MTV8dD0xNXx0ZHQ9aWlkOjMxNzgyNDY2MDQ1NjYyMzkwMTksY2xraWQ6MzE3ODI0NjYwNDU2NjIzOTAxOHxidz1MQVJHRXxwbG10PShjaGFubmVsOm51bGwgY2lkOjU0MjE0IGdiaDogaWlkOjMxNzgyNDY2MDQ1NjYyMzkwMTkgbWlkOjg2NDc2IHBhZ2VjaTozNDE5MGQzYi1kZWU0LTQ4ZDktODUwMS05YWU3ZTkxOTk1MzkgcGFyZW50cnE6YzFiNjY2OTcxN2EwYTRkNmIwY2QyN2Q4ZmZmZmM2NDIgcGlkOjEwMDAwMSBzaWQ6LTEgdGlkOmIzZTkzZGUxLWUxYmItNDBlMS04NDViLWM2MmZjMWExNmEyMSB0dHlwZTpIT01FX1BBR0VfQkFOTkVSX1ZFTE9DSVRZIHZpZDo5ZjYxMjJhY2Q4ODJkMGYxMDY0MTg2NWJkYmI2NjM4NjI4NWI1Y2EyNDE1MWQyMWVjMjE2NT"
		"BiZWYyNmNhNTY2KXx1bD1lbi1BVXxndWlkPWMxYjY2NmMzMTdhMGE0ZDZiMGNhYWY0MGZmZmY4NDE3fG09ODY0NzZ8bW9idHJrSWQ9Y2VmZjliNjYtOWRlMS00ZGI5LTgyNWQtN2U0MWQ5YmNjYjZjfnNBaTZoTThKbVlVTkh3VDhPdlFHZUxqOWpPNFNlV21QajNSeVNjaWdUamh+R0VtV3pSdFFSVVBPczc3QVFxa0E2MlhSQm00WGpnNE13UHFkRXV4bmFwWnx1Yz0xNQ==", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://svcs.ebay.com/delstats/imp/rtm?p=100004&mc="
		"YnM9MTV8dD0xNXx0ZHQ9aWlkOjMxNzgyNDY2MDQxODQwNTUxMTUsY2xraWQ6MzE3ODI0NjYwNDQ1MjQ5MDU3MHxidz1MQVJHRXxwbG10PShjaGFubmVsOm51bGwgY2lkOjU0NzEwIGdiaDogaWlkOjMxNzgyNDY2MDQxODQwNTUxMTUgbWlkOjg3NDY1IHBhZ2VjaToyYTgxZTUxYS01MmZlLTQzYTAtYWRkNC1kZDJiOTMxNTI0YTIgcGFyZW50cnE6YzFiNjY2OTcxN2EwYTRkNmIwY2QyN2Q4ZmZmZmM2NDIgcGlkOjEwMDAwNCBzaWQ6MzcwIHRpZDpiYzhmN2ViZC1jYjBkLTQyYTItODA3Zi0xYzMxODE3NjdiYjYgdHR5cGU6SE9NRV9QQUdFX0JBTk5FUl9WRUxPQ0lUWSB2aWQ6ZTJhZDVhZjExZGE4ZmY3YmYzZDllNjJmMTI2ZWNlZWQxODViZjYxYjA1YmI0NDUxNzNhZG"
		"Y1MWNlMWQ1ZGZmNyl8dWw9ZW4tQVV8Z3VpZD1jMWI2NjZjMzE3YTBhNGQ2YjBjYWFmNDBmZmZmODQxN3xtPTg3NDY1fG1vYnRya0lkPWNlZmY5YjY2LTlkZTEtNGRiOS04MjVkLTdlNDFkOWJjY2I2Y35zQWk2aE04Sm1ZVU5Id1Q4T3ZRR2VMajlqTzRTZVdtUGozUnlTY2lnVGpofkdFbVd6UnRRUlVQT3M3N0FRcWtBNjJYUkJtNFhqZzRNd1BxZEV1eG5hcFp8dWM9MTU=", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://ir.ebaystatic.com/rs/c/9527tracking/configuration.js?ts=5422492", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://www.googletagservices.com/tag/js/gpt.js", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://s.ns1p.net/?v=1619458322&a=c4cra1", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://securepubads.g.doubleclick.net/gpt/pubads_impl_2021071502.js?31061831", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://backstory.ebay.com.au/customer/v1/customer_image_service?pld="
		"%5B%7B%22guid%22%3A%22c1b666c317a0a4d6b0caaf40ffff8417%22%2C%22eventFamily%22%3A%22AUTO_TRACKING%22%2C%22agentVersion%22%3A%222.0.1%22%2C%22trackable%22%3A%7B%22trackableId%22%3A%22578f485c-35ab-4a89-b051-6ed928ee47c5%22%2C%22parentTrackableId%22%3Anull%2C%22instanceId%22%3A%22https%3A%2F%2Fwww.ebay.com.au%2F%22%2C%22screenId%22%3A%2282021922-eb3c-49dd-8576-b38c70a1db17%22%2C%22description%22%3A%22Electronics%2C%20Cars%2C%20Fashion%2C%20Collectibles%20%26%20More%20%7C%20eBay%22%2C%22entityId%22%3A"
		"%222481888%22%2C%22correlationId%22%3A%22f89ad337-e900-11eb-8d6d-7650a8cd509a%22%2C%22entityType%22%3A%22Page%22%7D%2C%22activity%22%3A%7B%22timestamp%22%3A1626747612179%2C%22category%22%3A%22Impression%22%2C%22type%22%3A%22VIEW.PAGE_LOAD%22%2C%22referer%22%3A%22%22%2C%22details%22%3A%7B%22ePageId%22%3A%222481888%22%2C%22nPageId%22%3A%222380057%22%7D%2C%22viewportWidth%22%3A1920%2C%22viewportHeight%22%3A969%7D%2C%22context%22%3A%7B%22utcOffset%22%3A-10%2C%22userLang%22%3A%22en-US%22%2C%22userAgent"
		"%22%3A%22Mozilla%2F5.0%20(Windows%20NT%206.3%3B%20Win64%3B%20x64)%20AppleWebKit%2F537.36%20(KHTML%2C%20like%20Gecko)%20Chrome%2F87.0.4280.66%20Safari%2F537.36%22%2C%22screenWidth%22%3A1920%2C%22screenHeight%22%3A1080%2C%22others%22%3A%7B%7D%7D%7D%5D&ct=1626747612187", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://i.ebayimg.com/images/g/kI4AAOSwI3lg7EJf/s-l200.webp", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://akamai-static.ebaycdn.net/images/g/gY4AAOSwNkxa2hpY/s-l500.jpg?t=be1dxf", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://akamai-static.ebaycdn.net/images/g/gY4AAOSwNkxa2hpY/s-l500.jpg?t=uf0bcg", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://akamai-static.ebaycdn.net/images/g/gY4AAOSwNkxa2hpY/s-l500.jpg?t=8ip9po", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://b.ns1p.net/?v=1619458322&x=7towbv&r=c4cra1,s3x4pb,125c00u:ii2,0,12y|ii2,0,12x|ii2,0,12w", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://ir.ebaystatic.com/rs/v/dxtuvtkk2q3hpkc1xveeo13iaek.js", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://ir.ebaystatic.com/rs/c/desk20210513_1.js", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://securepubads.g.doubleclick.net/gampad/ads?gdfp_req=1&pvsid=2698852531027382&correlator=2129365219772483&output=ldjh&impl=fif&eid=31060439%2C31061805%2C31061831%2C21064370%2C31061498%2C20211866%2C21067496&vrg=2021071502&ptt=17&sc=1&sfv=1-0-38&ecs=20210720&iu_parts=2455%2Cebay.au.homepage.cchp%2Ccchp&enc_prev_ius=%2F0%2F1%2F2&prev_iu_szs=970x90%7C728x90&fsfs=1&prev_scp="
		"ap%3DScandal%26g%3Dc1b666c317a0a4d6b0caaf40ffff8417%26us%3D13%26ot%3D1%26pr%3D20%26xp%3D20%26np%3D20%26u%3D9b1be96729284d35adebe16be24f340d%26ipp%3D0%26iccr%3D0%26gdprUser%3D0%26plmtid%3D100712%26acc%3Dext&cookie_enabled=1&bc=31&abxe=1&lmt=1626747626&dt=1626747626009&dlt=1626747594427&idt=27164&frm=20&biw=1903&bih=969&oid=3&adxs=0&adys=526&adks=666316433&ucis=1&ifi=1&u_tz=600&u_his=1&u_java=false&u_h=1080&u_w=1920&u_ah=1040&u_aw=1920&u_cd=24&u_nmime=4&u_sd=1&flash=0&url="
		"https%3A%2F%2Fwww.ebay.com.au%2F&vis=1&dmc=8&scr_x=0&scr_y=0&psz=1903x0&msz=970x-1&ga_vid=1725674302.1626747626&ga_sid=1626747626&ga_hid=306473595&ga_fc=false&fws=4&ohw=970&btvi=0", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://www.googletagservices.com/activeview/js/current/osd.js", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://securepubads.g.doubleclick.net/gampad/ads?gdfp_req=1&pvsid=2698852531027382&correlator=2129365219772483&output=ldjh&impl=fif&eid=31060439%2C31061805%2C31061831%2C21064370%2C31061498%2C20211866%2C21067496&vrg=2021071502&ptt=17&sc=1&sfv=1-0-38&ecs=20210720&iu_parts=2455%2Cebay.au.homepage.cchp%2Cbtf1&enc_prev_ius=%2F0%2F1%2F2&prev_iu_szs=300x250&fsfs=1&prev_scp="
		"ap%3DScandal%26g%3Dc1b666c317a0a4d6b0caaf40ffff8417%26us%3D13%26ot%3D1%26pr%3D20%26xp%3D20%26np%3D20%26u%3D20b9e5f374284da8884c61b8c7caa089%26ipp%3D0%26iccr%3D0%26gdprUser%3D0%26plmtid%3D100716%26acc%3Dext%26to_pb%3Dnobid%26to_bidder%3Dnobid%26to_adid%3Dnobid%26to_adsize%3Dnobid%26refresh%3D0%26rcount%3D0&cookie_enabled=1&bc=31&abxe=1&lmt=1626747626&dt=1626747626078&dlt=1626747594427&idt=27164&frm=20&biw=1903&bih=969&oid=3&adxs=1276&adys=2075&adks=2590623213&ucis=3&ifi=3&u_tz=600&u_his=1&u_java="
		"false&u_h=1080&u_w=1920&u_ah=1040&u_aw=1920&u_cd=24&u_nmime=4&u_sd=1&flash=0&url=https%3A%2F%2Fwww.ebay.com.au%2F&vis=1&dmc=8&scr_x=0&scr_y=0&psz=300x0&msz=300x0&ga_vid=1725674302.1626747626&ga_sid=1626747626&ga_hid=306473595&ga_fc=false&fws=4&ohw=300&btvi=1", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://securepubads.g.doubleclick.net/gampad/ads?gdfp_req=1&pvsid=2698852531027382&correlator=2129365219772483&output=ldjh&impl=fif&eid=31060439%2C31061805%2C31061831%2C21064370%2C31061498%2C20211866%2C21067496&vrg=2021071502&ptt=17&sc=1&sfv=1-0-38&ecs=20210720&iu_parts=2455%2Cebay.au.homepage.cchp%2Ccchp&enc_prev_ius=%2F0%2F1%2F2&prev_iu_szs=970x30&fsfs=1&prev_scp="
		"ap%3DScandal%26g%3Dc1b666c317a0a4d6b0caaf40ffff8417%26us%3D13%26ot%3D1%26pr%3D20%26xp%3D20%26np%3D20%26u%3D3c95209c376846e799de80f52ed79f51%26ipp%3D0%26iccr%3D0%26gdprUser%3D0%26plmtid%3D100713%26acc%3Dext&cookie_enabled=1&bc=31&abxe=1&lmt=1626747626&dt=1626747626051&dlt=1626747594427&idt=27164&frm=20&biw=1903&bih=969&oid=3&adxs=0&adys=0&adks=3532893633&ucis=2&ifi=2&u_tz=600&u_his=1&u_java=false&u_h=1080&u_w=1920&u_ah=1040&u_aw=1920&u_cd=24&u_nmime=4&u_sd=1&flash=0&url="
		"https%3A%2F%2Fwww.ebay.com.au%2F&vis=1&dmc=8&scr_x=0&scr_y=0&psz=1903x0&msz=1903x0&ga_vid=1725674302.1626747626&ga_sid=1626747626&ga_hid=306473595&ga_fc=false&fws=0&ohw=0&btvi=0", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://adservice.google.com/adsid/integrator.js?domain=www.ebay.com.au", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://rover.ebay.com.au/roverimp/0/0/9?imp=2046301&trknvp=cp%3D2547031%26ghi%3D98&1626747626239", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://tpc.googlesyndication.com/sodar/sodar2.js", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://rover.ebay.com.au/roverclk/0/0/9?trknvp=sid%3Dp2481888.m1383.l6435%26ts%3D1626747631470", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://pagead2.googlesyndication.com/pagead/gen_204?id=sodar2&v=224&t=2&li=gpt_2021071502&jk=2698852531027382&bg="
		"!ODulO3_NAAZjFomlYxY7ACkAdvg8WoSltZ3ta3Z6OxJxRRrqOS_Ie9t3I0JE218zAagzknYBhAjOtAIAAAEHUgAAAA5oAQcKAD3UivA8TbkHiH4zBPf3vEySzWBbq4O3hF7igAg_dWhDkTBsBCiosDAJ6Cy1HAkDoE7PtFRsH9mm84i5mc_0mQKTS8iGin6epOTQEUclVLOt--h98dUAwf0GbqKyX9Li-jWqGU7k9QVZf6cM_ICzfH7oxrs6TYzsPNz3AHXdNoqN-gQ4-j2ENvCdpGz9pT3cwoPRJJu1yzypcq9dS_bj_VCBVZUOH-SQZUTJSLYvJzpYoQsurRgAv-lV_NmroyR5KpNKbPTlp8hVRqygGbgX8xjimrdsCWv4jCqQZXenZNPKuUz6Gey1hi_c3TL_673P5_lWzWrZ-Gi5BZijleNfQ5gEUAqrsL865mYYeZH02LR-cNJLHx79P-z8OcidwAq9we8b6zI64jsGvfo2E7Geu"
		"3f5-LDmYX6JyzxG_Rsee0H6j8DBemUHk8RIHrwBTmvmcpLMuV9iiynfRER1VClIScoO43UeT--iBhl0W2Rmq9Wg53-09nNSak2C_7WycoUPblZfXfzklEj0iRbcKNYKR4DMyiA5QQQSiVgK4zK8RqRZlCPpsiDNKQubIdZ36NGX2LMCP0vRXDEYy54DEQf1B7cVbLCD7Ovmc0ecc0gTWF3rbiLktJCrTdpKhti5O_hune45-GA5rRds9vCgZcQWGYPpmuk_ExYwQ7su7O2-Z5Qg-jOO6p3rSBNrem_ynvUPzm5ppe0mgMLIgMXu_JpfHOyFDwopOfYeVJ-MNnJzPazKwTM1de4U9HfxuZFMTIpiMQvgGGnl5L06jeCBASzVfAFz_PAlrAlUx-EgvJAXwfcUhIpDrKYen7utZfwf1oQoY4AX0kbzmE6hJc4pQuwhphWj-8Nk3JqWkxj9w87i0UXOYU8Ed8JEwXbIRq4uqNHhEpYhCYOoNns"
		"BklIzZ0UcxhRSMl5rXssYrpHhb_w5q7DX1AurTZe8JuyzfnEHHV8SxwnDShU", "Referer={URL}.au/", "ENDITEM", 
		"Url=https://rover.ebay.com.au/roverimp/0/0/9?imp=2046301&trknvp=cp%3D2547031%26ghi%3D98&1626747754590", "Referer={URL}.au/", "ENDITEM", 
		"LAST");

	web_add_header("Access-Control-Request-Method", 
		"GET");

	web_add_header("Access-Control-Request-Headers", 
		"ufes-cache-key");

	web_add_auto_header("Origin", 
		"{URL}.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_custom_request("redeem",
		"URL={URL}/nap/napkinapi/v1/ticketing/redeem?ticket={C_ticket}",
		"Method=OPTIONS",
		"Resource=0",
		"Referer={URL}.au/",
		"Snapshot=t13.inf",
		"Mode=HTML",
		"LAST");

	lr_end_transaction("S01_AddItemtoCart_T10_Homepage",2);

	lr_think_time(thinktime);
	
	return 0;
}
# 4 "c:\\scripts_backup\\scenario1_test\\\\combined_Scenario1_Test.c" 2

# 1 "PromptSearch.c" 1
PromptSearch()
{
		
	char str[50]="";
    char str2[50]="";
    char str3[50]="";
    int n;
    int i;

    
     
  							 

   strcpy(str,lr_eval_string("{SearchString}"));
   
    n = strlen(str);    	 
        
 

 
    
							   
    
     for(i=1; i<=n; i++)
     	
     {
     	
     
     
     	strncpy (str2,str,i);
     	
     
      
     	 lr_save_string(str2, "str3");

    	lr_think_time(thinktime);
     	 
  web_reg_find("Text=prefix",   "LAST" );
	
	
	lr_start_transaction("S01_AddItemtoCart_T20_Promptsearch");
		
    	    
    	    	
	web_url("Auto_Search", 
		"URL=https://autosug.ebaystatic.com/autosug?kwd={str3}&_jgr=1&sId=15&_ch=0&_ps=1&callback=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={URL}.au/", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=https://pagead2.googlesyndication.com/pcs/activeview?xai=AKAOjsuk0tzjzmkP-U9gZtXghv7GOIfrfKZbEqsoeGfbUJKSBm9HgmXkgplokXLYdgGDNCIrC_ZphomL-0WOMW54JRz09owaDo1EA8yaz2TvTbhNcjid-Drd&sig=Cg0ArKJSzNKFfaiErEEeEAE&id=lidartos&mcvt=12387&p=0,467,34,1437&mtos=0,12251,12387,12422,12456&tos=0,12282,136,35,34&v=20210716&bin=7&avms=nio&bs=0,0&mc=0.88&if=1&app=0&itpl=19&adk=3532893633&rs=4&met=mue&la=0&cr=0&osd=1&vs=4&eosc=1&eosm=0&rst=1626747637645&dlt=23435&rpt=45&isd=0&msd=0&r=u&ec=0", "Referer=https://"
		"tpc.googlesyndication.com/", "ENDITEM", 
		"Url=https://pagead2.googlesyndication.com/pcs/activeview?xai=AKAOjssCROcNPlKNxCkpVEqR-YnQuWSni-t4a_bNIwOrUDS9s8cNfT_-r0Q-cympGvA29ybUhctNcm-osWk4IOeoDu_xLQTxE9ffYl7Coaq4ziRcGXE0eDlZ&sig=Cg0ArKJSzK4f58wQJKEgEAE&id=lidartos&mcvt=12647&p=526,467,616,1437&mtos=12647,12647,12647,12647,12647&tos=12647,0,0,0,0&v=20210716&bin=7&avms=nio&bs=0,0&mc=1&if=1&app=0&itpl=3&adk=666316433&rs=4&met=mue&la=0&cr=0&osd=1&vs=4&eosc=1&eosm=0&rst=1626747626459&dlt=46&rpt=34724&isd=0&msd=0&r=u&ec=0", "Referer=https://"
		"tpc.googlesyndication.com/", "ENDITEM", 
		"LAST");
	                
	                
	lr_end_transaction("S01_AddItemtoCart_T20_Promptsearch",2);
	
	lr_think_time(thinktime);
	
    		
     }
	
     
	return 0;
}
# 5 "c:\\scripts_backup\\scenario1_test\\\\combined_Scenario1_Test.c" 2

# 1 "Search.c" 1
Search()
{

	
     
 
 
 
 
 
 
 
 
 
 
 
 
 
 
		
     	
       web_reg_find("Text=aspectname",   "LAST" );
     
     	lr_start_transaction("S01_AddItemtoCart_T30_Search");
     	


		web_url("Search", 
		"URL={URL}.au/sch/i.html?_from=R40&_trksid=p2380057.m570.l1313&_nkw={SearchString}&_sacat=0", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={URL}.au/", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=https://i.ebayimg.com/00/z/LrQAAOSwq2pg3p7T/$_58.jpg", "Referer={URL}.au/sch/i.html?_from=R40&_trksid=p2380057.m570.l1313&_nkw=bike&_sacat=0", "ENDITEM", 
		"Url=https://ir.ebaystatic.com/pictures/aw/OCS_SelfService/IconSprite_InflowHelp.png", "Referer=https://ir.ebaystatic.com/rs/c/search-page-large-oF_v2zbk.css", "ENDITEM", 
		"LAST");
	
	
	
		lr_end_transaction("S01_AddItemtoCart_T30_Search",2);

		lr_think_time(thinktime);
			
	
	return 0;
}
# 6 "c:\\scripts_backup\\scenario1_test\\\\combined_Scenario1_Test.c" 2

# 1 "FirstBike.c" 1
FirstBike()
{
		
 
 
 
 
 
 
 
 
 
 
		
	 
		
	
	web_reg_save_param_regexp(
		"ParamName=C_srt1",
		"RegExp=srt=(.*?)&ssPageName",
		"Ordinal=5",
		"SEARCH_FILTERS",
		"Scope=Body",
		"IgnoreRedirections=No",
		 
		"LAST");
	
	lr_start_transaction("S01_AddItemtoCart_T40_FirstBike");
	

	
		web_url("Click first bike", 
		"URL={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={URL}.au/sch/i.html?_from=R40&_trksid=p2380057.m570.l1313&_nkw=bike&_sacat=0", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		"LAST");
	
	
	
	lr_end_transaction("S01_AddItemtoCart_T40_FirstBike",2);
	
	
lr_think_time(thinktime);
	
	return 0;
}
# 7 "c:\\scripts_backup\\scenario1_test\\\\combined_Scenario1_Test.c" 2

# 1 "SelectColor.c" 1
SelectColor()
{
	
	web_add_header("Access-Control-Request-Headers", 
		"ufes-cache-key");

	web_add_header("Access-Control-Request-Method", 
		"GET");

	web_add_header("Origin", "{URL}.au");
	
	lr_save_timestamp("Timestamp", "DIGITS=13", "LAST");


 
	lr_start_transaction("S01_AddItemtoCart_T50_SelectColor");
		

		web_custom_request("web_custom_request",
		"URL=https://rover.ebay.com.au/roverclk/0/0/9?trknvp=sid%3Dp2047675.l8638%26vi_msel%3D1%253A1%253A1&ts={Timestamp}",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Body=",
		"LAST");
	
	
	lr_end_transaction("S01_AddItemtoCart_T50_SelectColor",2);
	
	
	lr_think_time(thinktime);
	
	
	return 0;
}
# 8 "c:\\scripts_backup\\scenario1_test\\\\combined_Scenario1_Test.c" 2

# 1 "Addtocart.c" 1
Addtocart()
{
		lr_save_timestamp("Timestamp1", "DIGITS=13", "LAST");
		
		
		web_reg_save_param("C_ticketCart", "LB=ticket\":\"", "RB=\",","ord=1", "LAST");	
		

		web_reg_find("Text=provider",   "LAST" );
		
		
	
	lr_start_transaction("S01_AddItemtoCart_T60_ClicktoaddtoCart");
	
		web_add_auto_header("Sec-Fetch-Mode", 
		"navigate");

	web_add_auto_header("Sec-Fetch-Dest", 
		"iframe");



	web_add_header("Upgrade-Insecure-Requests", 
		"1");


	web_url("724_3", 
		"URL=https://stags.bluekai.com/site/724?ret=html&limit=4&btp=1&phint=eid%3D20047&phint=tcat%3D177831&phint=cg%3Dc1b6713217a0a6466f344290f9d5e5a3&phint=iid%3D313558273509&phint=pid%3D&phint=meta%3D888&phint=fm_segment%3D&phint=user_type%3D1166&phint=consent%3D0&phint=lost%3D0&phint=test%3Dmadrona1&phint=pageid%3D2047675&phint=symphony%3D0&phint=Plus%3D&phint=enccguid%3DAQADAAAAMPIoaNwGijXIP43i28D3rJ5%252F0Y8SClMvhUMnlxKUmRmhJK08yen%252FMjuDKardamTBSQ%253D%253D&phint=site_id%3D&phint="
		"encguid%3DAQADAAAAMIAm0hqlgBBY4t051oY5vZJc1o0RbOaaS%252FXZPJ3Zurve0p5ktgxgJnsDSIQhQVOnKg%253D%253D&phint=guid%3Dc1b666c317a0a4d6b0caaf40ffff8417&phint=item%3DUnisex%20Adult%20Mountain%20Bike%20Full%20Suspension%2026%26%23034%3B%2021%20Speed%20MTB%20Folding%20Bicycle&phint=kw%3Dbike&phint=eem%3d&phint=efn%3d&phint=eln%3d&phint=eph%3d&phint=ege%3d&phint=edob%3d&phint=efm%3d&phint=siteId%3d15&phint=ecguid%3dc1b6713217a0a6466f344290f9d5e5a3&phint=euid%3d&v=2&madrona=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", 
		"Snapshot=t83.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=https://content-autofill.googleapis.com/v1/pages/Chc2LjEuMTcxNS4xNDQyL2VuIChHR0xMKRIXCWdcfqC7uF29EgUNzyyHRRIFDfIXbIk=?alt=proto", "Referer=", "ENDITEM", 
		"Url=https://www.facebook.com/tr/?id=775033202546050&ev=PageView&dl="
		"https%3A%2F%2Fstags.bluekai.com%2Fsite%2F724%3Fret%3Dhtml%26limit%3D4%26btp%3D1%26phint%3Deid%253D20047%26phint%3Dtcat%253D177831%26phint%3Dcg%253Dc1b6713217a0a6466f344290f9d5e5a3%26phint%3Diid%253D313558273509%26phint%3Dpid%253D%26phint%3Dmeta%253D888%26phint%3Dfm_segment%253D%26phint%3Duser_type%253D1166%26phint%3Dconsent%253D0%26phint%3Dlost%253D0%26phint%3Dtest%253Dmadrona1%26phint%3Dpageid%253D2047675%26phint%3Dsymphony%253D0%26phint%3DPlus%253D%26phint%3Denccguid%253DAQADAAAAMPIoaNwGijXIP43i"
		"28D3rJ5%25252F0Y8SClMvhUMnlxKUmRmhJK08yen%25252FMjuDKardamTBSQ%25253D%25253D%26phint%3Dsite_id%253D%26phint%3Dencguid%253DAQADAAAAMIAm0hqlgBBY4t051oY5vZJc1o0RbOaaS%25252FXZPJ3Zurve0p5ktgxgJnsDSIQhQVOnKg%25253D%25253D%26phint%3Dguid%253Dc1b666c317a0a4d6b0caaf40ffff8417%26phint%3Ditem%253DUnisex%2520Adult%2520Mountain%2520Bike%2520Full%2520Suspension%252026%2526%2523034%253B%252021%2520Speed%2520MTB%2520Folding%2520Bicycle%26phint%3Dkw%253Dbike%26phint%3Deem%253d%26phint%3Defn%253d%26phint%3Deln%253"
		"d%26phint%3Deph%253d%26phint%3Dege%253d%26phint%3Dedob%253d%26phint%3Defm%253d%26phint%3DsiteId%253d15%26phint%3Decguid%253dc1b6713217a0a6466f344290f9d5e5a3%26phint%3Deuid%253d%26v%3D2%26madrona%3D1&rl=https%3A%2F%2Fwww.ebay.com.au%2Fitm%2F313558273509%3Fhash%3Ditem4901878de5%3Ag%3AL-YAAOSwASVg2CUt&if=true&ts=1626771373089&cd[e]=&cd[_e]=&cd[s]=15&cd[_s]=15&cd[pid]=2047675&cd[bn]=&sw=1920&sh=1080&ud[fn]=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855&ud[ln]="
		"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855&ud[ph]=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855&ud[ge]=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855&ud[db]=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855&ud[external_id]=c1b666c317a0a4d6b0caaf40ffff8417&v=2.9.33&r=stable&ec=0&o=30&it=1626771369953&coo=false&rqm=GET", "Referer=https://stags.bluekai.com/", "ENDITEM", 
		"Url=https://www.facebook.com/tr/?id=775033202546050&ev=Microdata&dl="
		"https%3A%2F%2Fstags.bluekai.com%2Fsite%2F724%3Fret%3Dhtml%26limit%3D4%26btp%3D1%26phint%3Deid%253D20047%26phint%3Dtcat%253D177831%26phint%3Dcg%253Dc1b6713217a0a6466f344290f9d5e5a3%26phint%3Diid%253D313558273509%26phint%3Dpid%253D%26phint%3Dmeta%253D888%26phint%3Dfm_segment%253D%26phint%3Duser_type%253D1166%26phint%3Dconsent%253D0%26phint%3Dlost%253D0%26phint%3Dtest%253Dmadrona1%26phint%3Dpageid%253D2047675%26phint%3Dsymphony%253D0%26phint%3DPlus%253D%26phint%3Denccguid%253DAQADAAAAMPIoaNwGijXIP43i"
		"28D3rJ5%25252F0Y8SClMvhUMnlxKUmRmhJK08yen%25252FMjuDKardamTBSQ%25253D%25253D%26phint%3Dsite_id%253D%26phint%3Dencguid%253DAQADAAAAMIAm0hqlgBBY4t051oY5vZJc1o0RbOaaS%25252FXZPJ3Zurve0p5ktgxgJnsDSIQhQVOnKg%25253D%25253D%26phint%3Dguid%253Dc1b666c317a0a4d6b0caaf40ffff8417%26phint%3Ditem%253DUnisex%2520Adult%2520Mountain%2520Bike%2520Full%2520Suspension%252026%2526%2523034%253B%252021%2520Speed%2520MTB%2520Folding%2520Bicycle%26phint%3Dkw%253Dbike%26phint%3Deem%253d%26phint%3Defn%253d%26phint%3Deln%253"
		"d%26phint%3Deph%253d%26phint%3Dege%253d%26phint%3Dedob%253d%26phint%3Defm%253d%26phint%3DsiteId%253d15%26phint%3Decguid%253dc1b6713217a0a6466f344290f9d5e5a3%26phint%3Deuid%253d%26v%3D2%26madrona%3D1&rl=https%3A%2F%2Fwww.ebay.com.au%2Fitm%2F313558273509%3Fhash%3Ditem4901878de5%3Ag%3AL-YAAOSwASVg2CUt&if=true&ts=1626771375960&cd[DataLayer]=%5B%5D&cd[Meta]=%7B%22title%22%3A%22%22%7D&cd[OpenGraph]=%7B%7D&cd[Schema.org]=%5B%5D&cd[JSON-LD]=%5B%5D&sw=1920&sh=1080&ud[fn]="
		"e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855&ud[ln]=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855&ud[ph]=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855&ud[ge]=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855&ud[db]=e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855&ud[external_id]=c1b666c317a0a4d6b0caaf40ffff8417&v=2.9.33&r=stable&ec=1&o=30&it=1626771369953&coo=false&es=automatic&tm=3&rqm=GET", "Referer=https:/"
		"/stags.bluekai.com/", "ENDITEM", 
		"Url=https://pagead2.googlesyndication.com/pcs/activeview?xai=AKAOjsu-7i_4w8938Eb3ERZr7m64wFlxBapidnRb7V69BlyHRwHUuKyjdrGfOCsM41swOn4hifS8eE7W2Z1sIZE5QPJbBK8nhGfZWXSmoavKjyVy1CdfBw5CjeEnMxo&sai=AMfl-YSppDwWR_L1_9yYXLEyFhUBIDv1iUFGDAGSrF9dHrfpeHhgrB5N5leifS77ytmldOfag0HEhRL5Q0tUgvzR3ceeCS-ozpWPKl1aFWgPHrfT8vGUbddckD2jZqLO&sig=Cg0ArKJSzFHM692kAZDgEAE&cid=CAASEuRoU4Z1sCorGgVua581A70wJA&id=lidartos&mcvt=26247&p=524,1379,774,1679&mtos=26247,26247,26247,26247,26247&tos=26247,0,0,0,0&v=20210716&bin=7&avms"
		"=nio&bs=0,0&mc=1&if=1&app=0&itpl=22&adk=4028896849&rs=4&met=mue&la=0&cr=0&osd=1&vs=4&eosc=1&eosm=0&rst=1626771353940&dlt=962&rpt=367&isd=0&msd=0&r=u&ec=0", "Referer=https://1013c29984b68ac6c91c1baa94386e7b.safeframe.googlesyndication.com/", "ENDITEM", 
		"Url=https://rover.ebay.com.au/roverclk/0/0/9?trknvp=sid%3Dp2047675.l51430%26ex1%3D15418&ts=1626771382999", "Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", "ENDITEM", 
		"Url={URL}.au/rec/plmt/100562?ts={Timestamp1}&callback=handleMFEResponse&si=15&fmt=json&enc=UTF-8&cguid=c1b6713217a0a6466f344290f9d5e5a3&guid=c1b666c317a0a4d6b0caaf40ffff8417&ad_sizes=300x250&ad_rcount=1&pageFamily=VIP&itm=313558273509", "Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", "ENDITEM", 
		"LAST");
	
	lr_end_transaction("S01_AddItemtoCart_T60_ClicktoaddtoCart",2);
	
		lr_think_time(thinktime);
	
	return 0;
}
# 9 "c:\\scripts_backup\\scenario1_test\\\\combined_Scenario1_Test.c" 2

# 1 "Addplan.c" 1
Addplan()
{
	
	lr_start_transaction("S01_AddItemtoCart_T70_ClickNoThanksButton");
	
	
	web_custom_request("redeem_6", 
		"URL={URL}/nap/napkinapi/v1/ticketing/redeem?ticket={C_ticketCart}", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", 
		"Snapshot=t85.inf", 
		"Mode=HTML", 
		"EXTRARES", 
		"Url=redeem?ticket={C_ticketCart}", "Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", "ENDITEM", 
		"Url=https://securepubads.g.doubleclick.net/gampad/ads?gdfp_req=1&pvsid=2540991449657275&correlator=2256885127250256&output=ldjh&impl=fif&eid=31061160%2C31061848%2C31061199%2C20211866&vrg=2021071501&ptt=17&sc=1&sfv=1-0-38&ecs=20210720&iu_parts=2455%2Cebay.au.vip%2CMPU&enc_prev_ius=%2F0%2F1%2F2&prev_iu_szs=300x250&fsfs=1&ris=34&rcs=1&prev_scp="
		"ap%3DScandal%26cat%3D888%2C7294%2C177831%26iid%3D313558273509%26it%3DUnisex%2520Adult%2520Mountain%2520Bike%2520Full%2520Suspension%252026%252021%2520Speed%2520MTB%2520Folding%2520Bicycle%26ip%3D32%26ccode%3DAUD%26if%3Db%26smdid%3D1520453025306022531802AAAAAAAAAA%26cg%3Dc1b6713217a0a6466f344290f9d5e5a3%26g%3Dc1b666c317a0a4d6b0caaf40ffff8417%26us%3D13%26um%3D0%26ot%3D1%26fvi%3D888%26svi%3D7294%26tvi%3D177831%26kw%3DUnisex%2520Adult%2520Mountain%2520Bike%2520Full%2520Suspension%252026%252021%2520Spe"
		"ed%2520MTB%2520Folding%2520Bicycle%26lkw%3Dbike%26cid%3D0%26nc%3D0%26rd%3D19691231%26fm%3D0%26sfm%3D0%26ic%3D0%26pr%3D20%26xp%3D20%26np%3D20%26u%3D5945e7bafd5b4f01a970bc622cd319b7%26bb%3D0%26dd%3D0%26c2c%3D0%26ipp%3D0%26iccr%3D0%26gdprUser%3D0%26plmtid%3D100562%26acc%3Dext%26slc%3D19476%2C20506%2C20511%2C20501%2C23641%2C26125%2C26314%2C26302%2C216%2C17220%2C19471%2C20016%2C19781%2C19811%26to_pb%3Dnobid%26to_bidder%3Dnobid%26to_adid%3Dnobid%26to_adsize%3Dnobid%26refresh%3D1%26rcount%3D1&eri=1&"
		"cookie=ID%3Dc805df014454b760%3AT%3D1626747633%3AS%3DALNI_Mb29AVfagXNae3XvZe4CT8icknGYw&bc=31&abxe=1&lmt=1626771384&dt=1626771384017&dlt=1626771334272&idt=15278&frm=20&biw=1903&bih=969&oid=3&adxs=1379&adys=524&adks=4028896849&ucis=3&ifi=3&u_tz=600&u_his=3&u_java=false&u_h=1080&u_w=1920&u_ah=1040&u_aw=1920&u_cd=24&u_nplug=3&u_nmime=4&u_sd=1&flash=0&url=https%3A%2F%2Fwww.ebay.com.au%2Fitm%2F313558273509%3Fhash%3Ditem4901878de5%3Ag%3AL-YAAOSwASVg2CUt&ref="
		"https%3A%2F%2Fwww.ebay.com.au%2Fsch%2Fi.html%3F_from%3DR40%26_trksid%3Dp2380057.m570.l1313%26_nkw%3Dbike%26_sacat%3D0&vis=1&dmc=8&scr_x=0&scr_y=0&psz=300x592&msz=300x254&ga_vid=2053175122.1626771350&ga_sid=1626771350&ga_hid=1420897058&ga_fc=false&fws=0&ohw=0&btvi=0", "Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", "ENDITEM", 
		"Url=https://adservice.google.com.au/adsid/integrator.js?domain=www.ebay.com.au", "Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", "ENDITEM", 
		"Url=https://adservice.google.com/adsid/integrator.js?domain=www.ebay.com.au", "Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", "ENDITEM", 
		"LAST");
	
	
	web_add_auto_header("Sec-Fetch-Mode", 
		"no-cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"same-site");

	web_custom_request("9_6",
		"URL=https://pulsar.ebay.com.au/plsr/mpe/0/SAND/9?pld=%5B%7B%22ef%22%3A%22SAND%22%2C%22ea%22%3A%223PADS%22%2C%22pge%22%3A2367355%2C%22plsUBT%22%3A1%2C%22app%22%3A%22Sandwich%22%2C%22callingEF%22%3A%22SAND%22%2C%22difTS%22%3A1%2C%22eventOrder%22%3A0%2C%22cp%22%3A2047675%2C%22scandal_trk%22%3A%22meid%3A{C_ticketCart}%2Cplid%3A100562%2Cw%3A300%2Ch%3A250%2Ccid%3A138222862143%2Cliid%3A900453536%2Cempty%3Afalse%2Cprvdr%3Ahybrid%2Cerrmsg%3AUnexpected%2520error%2520in%2520Napkin%2520Ajax%2520call%2Cafs%3A1626771349561%2Cafe%3A1626771353939%2Cars%3A1626771353940%2Care%3A1626771356764%2Civ%3A1626771355431%2Cview1s%3Atrue%7Cmeid%3A3c11a1871d054b0da358b9d6e0c1663a%2Cplid%3A100567%2Cw%3A375%2Ch%3A35%2Ccid%3A138273363069%2Cliid%3A5094698128%2Cempty%3Afalse%2Cprvdr%3AdfpNativeDisplay%2Cafs%3A1626771349565%2Cafe%3A1626771353840%2Cars%3A1626771353840%2Care%3A1626771356639%22%2C%22scandal_timings%22%3A%22sjsv%3A2.1.31%2Cload%3A1626771349508%2Cdata_collected%3A1626771383095%2Cgss_ts%3A1626771342041%2Cbw%3A1920%2Cbh%3A969%2Csh%3A108"
		"0%2Csw%3A1920%22%7D%5D",
		"Method=POST",
		"Resource=0",
		"RecContentType=image/gif",
		"Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt",
		"Snapshot=t86.inf",
		"EncType=text/plain;charset=UTF-8",
		"LAST");

	
	 
	web_reg_save_param_regexp(
		"ParamName=C_Srt",
		"RegExp=\\ data-token=\"(.*?)\"><span",
		"SEARCH_FILTERS",
		"Scope=Body",
		"IgnoreRedirections=No",
		"LAST");
	
web_reg_find("Text=samplingRate",   "LAST" );

	web_url("add",
		"URL=https://cart.payments.ebay.com.au/sc/add?srt={C_srt1}&ssPageName=CART:ATC&item=iid:313558273509,qty:1,vid:612384340773",
		"Resource=0",
		"RecContentType=text/html",
		"Referer={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt",
		"Snapshot=t90.inf",
		"Mode=HTML",
		"LAST");
	
		(web_remove_auto_header("X-Client-Data", "ImplicitGen=Yes", "LAST"));

	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_add_auto_header("Origin", 
		"https://cart.payments.ebay.com.au");

	web_add_auto_header("Sec-Fetch-Dest", 
		"empty");

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

		web_reg_find("Text=logName",   "LAST" );
		
	web_custom_request("client-logging",
		"URL=https://cart.payments.ebay.com.au/api/client-logging",
		"Method=POST",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=https://cart.payments.ebay.com.au/",
		"Snapshot=t93.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"logType\":\"info\",\"logName\":\"[CLIENT_LOAD_TIME]\",\"clientLoadStart\":4102.985000004992,\"clientLoadEnd\":4409.590000053868,\"clientLoadTotal\":306.6050000488758,\"logMessage\":\"\",\"srt\":\"{C_Srt}\"}",
		"LAST");

	
	
	lr_end_transaction("S01_AddItemtoCart_T70_ClickNoThanksButton",2);
	
	lr_think_time(thinktime);
		
	return 0;
}
# 10 "c:\\scripts_backup\\scenario1_test\\\\combined_Scenario1_Test.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{
	return 0;
}
# 11 "c:\\scripts_backup\\scenario1_test\\\\combined_Scenario1_Test.c" 2

