FirstBike()
{
		
//		
//		/*Correlation comment - Do not change!  Original value='7670a7a082ee4a608220fc01af62512a' Name ='C_ticket' Type ='Manual'*/
//	web_reg_save_param_regexp(
//		"ParamName=C_ticket",
//		"RegExp=,\"refreshDelay\":35000,\"refreshCap\":5,\"isLazyLoad\":false,\"inViewRefresh\":false,\"isGSSEnabled\":true,\"env\":\"production\",\"ticket\":\"(.*?)\",",
//		SEARCH_FILTERS,
//		"Scope=Body",
//		"IgnoreRedirections=No",
//		//"RequestUrl=*/313558273509*",
//		LAST);
		
	//	web_reg_find("Text=FILTER_APPLIED",   LAST );
		
	
	web_reg_save_param_regexp(
		"ParamName=C_srt1",
		"RegExp=srt=(.*?)&ssPageName",
		"Ordinal=5",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		//"RequestUrl=*/313558273509*",
		LAST);
	
	lr_start_transaction("S01_AddItemtoCart_T40_FirstBike");
	

	
		web_url("Click first bike", 
		"URL={URL}.au/itm/313558273509?hash=item4901878de5:g:L-YAAOSwASVg2CUt", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={URL}.au/sch/i.html?_from=R40&_trksid=p2380057.m570.l1313&_nkw=bike&_sacat=0", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		LAST);
	
	
	
	lr_end_transaction("S01_AddItemtoCart_T40_FirstBike",LR_AUTO);
	
	
lr_think_time(thinktime);
	
	return 0;
}
