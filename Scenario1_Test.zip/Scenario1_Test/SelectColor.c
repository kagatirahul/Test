SelectColor()
{
	
	web_add_header("Access-Control-Request-Headers", 
		"ufes-cache-key");

	web_add_header("Access-Control-Request-Method", 
		"GET");

	web_add_header("Origin", "{URL}.au");
	
	lr_save_timestamp("Timestamp", "DIGITS=13", LAST);


 
	lr_start_transaction("S01_AddItemtoCart_T50_SelectColor");
		

		web_custom_request("web_custom_request",
		"URL=https://rover.ebay.com.au/roverclk/0/0/9?trknvp=sid%3Dp2047675.l8638%26vi_msel%3D1%253A1%253A1&ts={Timestamp}",
		"Method=GET",
		"TargetFrame=",
		"Resource=0",
		"Referer=",
		"Body=",
		LAST);
	
	
	lr_end_transaction("S01_AddItemtoCart_T50_SelectColor",LR_AUTO);
	
	
	lr_think_time(thinktime);
	
	
	return 0;
}
