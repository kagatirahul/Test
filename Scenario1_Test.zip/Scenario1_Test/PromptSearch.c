PromptSearch()
{
		
	char str[50]="";
    char str2[50]="";
    char str3[50]="";
    int n;
    int i;

    
     
  							//Copy a string and to find length of the string

   strcpy(str,lr_eval_string("{SearchString}"));
   
    n = strlen(str);    	//string length stored in n
        
//  lr_output_message(str);

//  lr_output_message("Total lenght of the charaters :%d",n);
    
							  //Loop to run the same number of times of the length of the sting
    
     for(i=1; i<=n; i++)
     	
     {
     	
    // 	lr_output_message("lenght of the charater :%d",i);
     
     	strncpy (str2,str,i);
     	
    // 	 lr_output_message(str2);
      
     	 lr_save_string(str2, "str3");

    	lr_think_time(thinktime);
     	 
  web_reg_find("Text=prefix",   LAST );
	
	
	lr_start_transaction("S01_AddItemtoCart_T20_Promptsearch");
		
    	    
    	    	
	web_url("Auto_Search", 
		"URL=https://autosug.ebaystatic.com/autosug?kwd={str3}&_jgr=1&sId=15&_ch=0&_ps=1&callback=0", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer={URL}.au/", 
		"Snapshot=t45.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://pagead2.googlesyndication.com/pcs/activeview?xai=AKAOjsuk0tzjzmkP-U9gZtXghv7GOIfrfKZbEqsoeGfbUJKSBm9HgmXkgplokXLYdgGDNCIrC_ZphomL-0WOMW54JRz09owaDo1EA8yaz2TvTbhNcjid-Drd&sig=Cg0ArKJSzNKFfaiErEEeEAE&id=lidartos&mcvt=12387&p=0,467,34,1437&mtos=0,12251,12387,12422,12456&tos=0,12282,136,35,34&v=20210716&bin=7&avms=nio&bs=0,0&mc=0.88&if=1&app=0&itpl=19&adk=3532893633&rs=4&met=mue&la=0&cr=0&osd=1&vs=4&eosc=1&eosm=0&rst=1626747637645&dlt=23435&rpt=45&isd=0&msd=0&r=u&ec=0", "Referer=https://"
		"tpc.googlesyndication.com/", ENDITEM, 
		"Url=https://pagead2.googlesyndication.com/pcs/activeview?xai=AKAOjssCROcNPlKNxCkpVEqR-YnQuWSni-t4a_bNIwOrUDS9s8cNfT_-r0Q-cympGvA29ybUhctNcm-osWk4IOeoDu_xLQTxE9ffYl7Coaq4ziRcGXE0eDlZ&sig=Cg0ArKJSzK4f58wQJKEgEAE&id=lidartos&mcvt=12647&p=526,467,616,1437&mtos=12647,12647,12647,12647,12647&tos=12647,0,0,0,0&v=20210716&bin=7&avms=nio&bs=0,0&mc=1&if=1&app=0&itpl=3&adk=666316433&rs=4&met=mue&la=0&cr=0&osd=1&vs=4&eosc=1&eosm=0&rst=1626747626459&dlt=46&rpt=34724&isd=0&msd=0&r=u&ec=0", "Referer=https://"
		"tpc.googlesyndication.com/", ENDITEM, 
		LAST);
	                
	                
	lr_end_transaction("S01_AddItemtoCart_T20_Promptsearch",LR_AUTO);
	
	lr_think_time(thinktime);
	
    		
     }
	
     
	return 0;
}
