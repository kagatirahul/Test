Search()
{

	
     
//     /*Correlation comment - Do not change!  Original value='item4901878de5:g:L-YAAOSwASVg2CUt' Name ='C_hash' Type ='Manual'*/
//	web_reg_save_param_regexp(
//		"ParamName=C_hashrandom",
//		"RegExp=hash=(.*?)><div\\ class",
//		"Ordinal=ALL",
//		SEARCH_FILTERS,
//		"Scope=Body",
//		"IgnoreRedirections=No",
//		"RequestUrl=*/i.html*",
//		LAST);
//     
//
//	
//		web_reg_save_param("C_hash", "LB=hash", "RB=amp;","ORD=ALL", LAST);
		
     	
       web_reg_find("Text=aspectname",   LAST );
     
     	lr_start_transaction("S01_AddItemtoCart_T30_Search");
     	


		web_url("Search", 
		"URL={URL}.au/sch/i.html?_from=R40&_trksid=p2380057.m570.l1313&_nkw={SearchString}&_sacat=0", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={URL}.au/", 
		"Snapshot=t50.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://i.ebayimg.com/00/z/LrQAAOSwq2pg3p7T/$_58.jpg", "Referer={URL}.au/sch/i.html?_from=R40&_trksid=p2380057.m570.l1313&_nkw=bike&_sacat=0", ENDITEM, 
		"Url=https://ir.ebaystatic.com/pictures/aw/OCS_SelfService/IconSprite_InflowHelp.png", "Referer=https://ir.ebaystatic.com/rs/c/search-page-large-oF_v2zbk.css", ENDITEM, 
		LAST);
	
	
	
		lr_end_transaction("S01_AddItemtoCart_T30_Search",LR_AUTO);

		lr_think_time(thinktime);
			
	
	return 0;
}